<?php
header('Content-Type: application/json');

echo "=== TEST CREAR USUARIO ===\n\n";

$url = 'http://localhost:8000/api/api/users.php';
$data = json_encode([
    'username' => 'test_wizard',
    'email' => 'test_wizard@test.com',
    'password' => 'password123',
    'first_name' => 'Test',
    'last_name' => 'Wizard',
    'role_id' => 11,
    'desk_id' => 4,
    'status' => 'active'
]);

echo "URL: $url\n";
echo "Data: $data\n\n";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$error = curl_error($ch);

$headers = substr($response, 0, $headerSize);
$body = substr($response, $headerSize);

curl_close($ch);

echo "HTTP Code: $httpCode\n";
echo "Headers:\n$headers\n";
echo "Body:\n$body\n";

if ($error) {
    echo "cURL Error: $error\n";
}

$decoded = json_decode($body, true);
if ($decoded) {
    echo "\n📋 Respuesta decodificada:\n";
    print_r($decoded);
} else {
    echo "\n❌ Error decodificando JSON: " . json_last_error_msg() . "\n";
}
?>