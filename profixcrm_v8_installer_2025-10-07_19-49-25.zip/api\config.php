<?php
require_once __DIR__ . '/../config/constants.php';

require_once __DIR__ . '/../public/api/config.php';