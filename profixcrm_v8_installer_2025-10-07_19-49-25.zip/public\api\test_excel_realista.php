<?php
/**
 * Test realista de importación de Excel
 */

// Crear un archivo Excel de prueba temporal
$tempFile = tempnam(sys_get_temp_dir(), 'excel_test_') . '.xlsx';

// Crear archivo Excel con contenido real
createTestExcel($tempFile);

function createTestExcel($filename) {
    // Crear un XLSX básico con contenido
    $zip = new ZipArchive;
    if ($zip->open($filename, ZipArchive::CREATE) !== TRUE) {
        die("No se pudo crear archivo ZIP\n");
    }
    
    // Crear archivo rels
    $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>');
    
    // Crear workbook.xml
    $zip->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheets>
    <sheet name="Sheet1" sheetId="1" r:id="rId1" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>
  </sheets>
</workbook>');
    
    // Crear workbook rels
    $zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>
</Relationships>');
    
    // Crear sharedStrings.xml
    $sharedStrings = [
        'nombre', 'apellido', 'email', 'telefono', 'pais', 'ciudad'
    ];
    
    $sharedXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="' . count($sharedStrings) . '" uniqueCount="' . count($sharedStrings) . '">';
    
    foreach ($sharedStrings as $string) {
        $sharedXml .= "<si><t>$string</t></si>";
    }
    $sharedXml .= '</sst>';
    $zip->addFromString('xl/sharedStrings.xml', $sharedXml);
    
    // Crear sheet1.xml con datos
    $sheetXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetData>
    <!-- Headers -->
    <row r="1">
      <c r="A1" t="s"><v>0</v></c>
      <c r="B1" t="s"><v>1</v></c>
      <c r="C1" t="s"><v>2</v></c>
      <c r="D1" t="s"><v>3</v></c>
      <c r="E1" t="s"><v>4</v></c>
      <c r="F1" t="s"><v>5</v></c>
    </row>
    <!-- Data -->
    <row r="2">
      <c r="A2"><v>Juan</v></c>
      <c r="B2"><v>Pérez</v></c>
      <c r="C2"><v>juan.perez@email.com</v></c>
      <c r="D2"><v>+34 600 123 456</v></c>
      <c r="E2"><v>España</v></c>
      <c r="F2"><v>Madrid</v></c>
    </row>
    <row r="3">
      <c r="A3"><v>María</v></c>
      <c r="B3"><v>García</v></c>
      <c r="C3"><v>maria.garcia@email.com</v></c>
      <c r="D3"><v>+34 600 789 012</v></c>
      <c r="E3"><v>España</v></c>
      <c r="F3"><v>Barcelona</v></c>
    </row>
    <row r="4">
      <c r="A4"><v>Carlos</v></c>
      <c r="B4"><v>López</v></c>
      <c r="C4"><v>carlos.lopez@email.com</v></c>
      <c r="D4"><v>+34 600 345 678</v></c>
      <c r="E4"><v>España</v></c>
      <c r="F4"><v>Valencia</v></c>
    </row>
  </sheetData>
</worksheet>';
    
    $zip->addFromString('xl/worksheets/sheet1.xml', $sheetXml);
    
    // Crear content_types
    $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
</Types>';
    
    $zip->addFromString('[Content_Types].xml', $contentTypes);
    $zip->close();
}

echo "=== Archivo Excel de prueba creado ===\n";
echo "Ruta: $tempFile\n";
echo "Tamaño: " . filesize($tempFile) . " bytes\n\n";

// Ahora simular la petición POST al importador
echo "=== Probando importación de Excel ===\n";

// Configurar $_FILES y $_POST
$_FILES = [
    'file' => [
        'name' => 'leads_test.xlsx',
        'type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'tmp_name' => $tempFile,
        'error' => 0,
        'size' => filesize($tempFile)
    ]
];

$_POST = [];

// Incluir el archivo de importación
ob_start();
require_once 'import-simple.php';
$output = ob_get_clean();

// Mostrar resultados
$jsonOutput = json_decode($output, true);
if ($jsonOutput) {
    echo "Respuesta JSON:\n";
    echo json_encode($jsonOutput, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
} else {
    echo "Respuesta cruda:\n";
    echo $output . "\n";
}

// Limpiar
unlink($tempFile);
echo "\n=== Test completado y archivo temporal eliminado ===\n";