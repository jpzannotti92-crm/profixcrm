<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Log de debug
$logData = [
    'timestamp' => date('Y-m-d H:i:s'),
    'method' => $_SERVER['REQUEST_METHOD'],
    'headers' => getallheaders(),
    'raw_input' => file_get_contents('php://input'),
    'get_params' => $_GET,
    'post_params' => $_POST
];

// Escribir log para debug
file_put_contents(__DIR__ . '/debug_frontend.log', json_encode($logData, JSON_PRETTY_PRINT) . "\n\n", FILE_APPEND);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Simular login
    $input = json_decode(file_get_contents('php://input'), true);
    
    if ($input && isset($input['username']) && isset($input['password'])) {
        // Simular respuesta de login exitoso
        echo json_encode([
            'success' => true,
            'message' => 'Login simulado exitoso',
            'token' => 'test-jwt-token-12345',
            'user' => [
                'id' => 1,
                'username' => $input['username'],
                'permissions' => ['leads.view', 'users.view']
            ]
        ]);
    } else {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Datos de login requeridos'
        ]);
    }
} else {
    // GET request - mostrar info de debug
    echo json_encode([
        'success' => true,
        'message' => 'Frontend flow test endpoint',
        'debug_info' => $logData
    ]);
}
?>