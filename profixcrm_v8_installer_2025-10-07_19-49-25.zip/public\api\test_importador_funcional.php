<?php
/**
 * Test del importador funcional
 * Procesa leads válidos y muestra reporte final
 */

require_once __DIR__ . '/../../platform_check_bypass.php';
require_once __DIR__ . '/../../src/Database/Connection.php';

use iaTradeCRM\Database\Connection;

// Crear archivo CSV de prueba con datos válidos
$csvData = [
    'nombre,apellido,email,telefono,pais,ciudad,empresa,puesto',
    'Juan,Pérez,juan.perez@empresa.com,555-1234,México,Ciudad de México,Tech Corp,Manager',
    'María,García,maria.garcia@gmail.com,555-5678,Colombia,Bogotá,Consulting SA,Analista',
    'Carlos,López,carlos.lopez@yahoo.es,555-9012,Argentina,Buenos Aires,Import SL,Director',
    'Ana,Rodríguez,ana.rodriguez@outlook.com,555-3456,Chile,Santiago,Export Ltda,Gerente',
    'Luis,Martínez,luis.martinez@hotmail.com,555-7890,Perú,Lima,Negocios SAC,Asistente'
];

$tempFile = tempnam(sys_get_temp_dir(), 'test_funcional_');
file_put_contents($tempFile, implode("\n", $csvData));

echo "=== ARCHIVO DE PRUEBA CREADO ===\n";
echo "Ruta: $tempFile\n";
echo "Tamaño: " . filesize($tempFile) . " bytes\n\n";

// Conectar a base de datos
try {
    $connection = Connection::getInstance();
    $pdo = $connection->getConnection();
    echo "✅ Conexión a base de datos exitosa\n";
    
    // Contar leads antes
    $stmt = $pdo->query('SELECT COUNT(*) FROM leads');
    $leadsBefore = $stmt->fetchColumn();
    echo "Leads antes de importar: $leadsBefore\n\n";
    
} catch (Exception $e) {
    echo "❌ Error conectando a base de datos: " . $e->getMessage() . "\n";
    exit;
}

// Simular POST y FILES
$_SERVER['REQUEST_METHOD'] = 'POST';
$_POST = [];
$_FILES = [
    'file' => [
        'name' => 'test_leads.csv',
        'type' => 'text/csv',
        'tmp_name' => $tempFile,
        'error' => UPLOAD_ERR_OK,
        'size' => filesize($tempFile)
    ]
];

// Ejecutar importador
ob_start();
require_once 'importador_funcional.php';
$output = ob_get_clean();

// Analizar resultados
echo "=== RESULTADOS DE IMPORTACIÓN ===\n";
echo "Salida cruda: $output\n\n";

$jsonStart = strpos($output, '{');
if ($jsonStart !== false) {
    $jsonStr = substr($output, $jsonStart);
    $result = json_decode($jsonStr, true);
    
    if (json_last_error() === JSON_ERROR_NONE) {
        if ($result['success']) {
            echo "✅ Importación exitosa!\n";
            echo "📊 RESUMEN FINAL:\n";
            echo "   📋 Total procesados: " . $result['data']['total_rows'] . "\n";
            echo "   ✅ Importados: " . $result['data']['imported_rows'] . "\n";
            echo "   ⚠️  Duplicados: " . $result['data']['duplicate_rows'] . "\n";
            echo "   ❌ Fallidos: " . $result['data']['failed_rows'] . "\n\n";
            
            if (!empty($result['data']['errors'])) {
                echo "📝 PRIMEROS ERRORES:\n";
                foreach (array_slice($result['data']['errors'], 0, 3) as $error) {
                    echo "   Fila {$error['row']}: " . implode(', ', $error['errors']) . "\n";
                }
                echo "\n";
            }
        } else {
            echo "❌ Error en importación: " . $result['message'] . "\n";
        }
    } else {
        echo "❌ Error decodificando JSON: " . json_last_error_msg() . "\n";
    }
} else {
    echo "❌ No se encontró JSON en la respuesta\n";
}

// Contar leads después
try {
    $stmt = $pdo->query('SELECT COUNT(*) FROM leads');
    $leadsAfter = $stmt->fetchColumn();
    echo "📈 Leads después de importar: $leadsAfter\n";
    echo "📊 Diferencia: " . ($leadsAfter - $leadsBefore) . " leads nuevos\n\n";
    
    // Mostrar últimos leads importados
    $stmt = $pdo->query('SELECT first_name, last_name, email, created_at FROM leads ORDER BY id DESC LIMIT 3');
    $recentLeads = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "🏆 ÚLTIMOS LEADS IMPORTADOS:\n";
    foreach ($recentLeads as $lead) {
        echo "   • {$lead['first_name']} {$lead['last_name']} - {$lead['email']} ({$lead['created_at']})\n";
    }
    echo "\n";
    
} catch (Exception $e) {
    echo "❌ Error consultando base de datos: " . $e->getMessage() . "\n";
}

// Limpiar
unlink($tempFile);
echo "🧹 Archivo temporal eliminado\n";
echo "\n=== IMPORTACIÓN FINALIZADA ===\n";