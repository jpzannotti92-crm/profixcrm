<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Testing leads API...\n";

try {
    require_once 'database.php';
    echo "Database.php loaded\n";
    
    // Simular token válido
    $_SERVER['HTTP_AUTHORIZATION'] = 'Bearer eyJ1c2VyX2lkIjoxLCJ1c2VybmFtZSI6ImFkbWluIiwiZXhwIjoxNzU4MDM4MzUzfQ==';
    
    $user = verifyToken();
    echo "Token verified: " . json_encode($user) . "\n";
    
    $pdo = getDbConnection();
    echo "Database connected\n";
    
    // Crear tabla leads si no existe
    $createTable = "
        CREATE TABLE IF NOT EXISTS leads (
            id INT AUTO_INCREMENT PRIMARY KEY,
            first_name VARCHAR(100),
            last_name VARCHAR(100),
            email VARCHAR(255) UNIQUE,
            phone VARCHAR(50),
            country VARCHAR(100),
            status ENUM('new', 'contacted', 'qualified', 'converted', 'lost') DEFAULT 'new',
            source VARCHAR(100) DEFAULT 'manual',
            desk_id INT NULL,
            assigned_user_id INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ";
    
    $pdo->exec($createTable);
    echo "Leads table created/verified\n";
    
    // Insertar datos de prueba
    $insertTest = "
        INSERT IGNORE INTO leads (first_name, last_name, email, phone, country, status, source) 
        VALUES 
        ('Juan', 'Pérez', 'juan@test.com', '+1234567890', 'España', 'new', 'manual'),
        ('María', 'García', 'maria@test.com', '+0987654321', 'México', 'contacted', 'web')
    ";
    
    $pdo->exec($insertTest);
    echo "Test data inserted\n";
    
    // Probar consulta de leads
    $stmt = $pdo->query("SELECT * FROM leads LIMIT 5");
    $leads = $stmt->fetchAll();
    echo "Leads found: " . count($leads) . "\n";
    echo "Sample lead: " . json_encode($leads[0] ?? 'none') . "\n";
    
    echo "Leads API test passed!\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . " Line: " . $e->getLine() . "\n";
    echo "Stack trace: " . $e->getTraceAsString() . "\n";
}
?>