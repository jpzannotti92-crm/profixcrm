<?php
/**
 * Configuración de Base de Datos - Auto-generado
 * Fecha: 2025-10-07 17:40:18
 */

define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'spin2pay_profixcrm');
define('DB_USER', 'spin2pay_profixadmin');
define('DB_PASS', 'Jeanpi9941991@');

// Configuración adicional de producción
define('PRODUCTION_MODE', true);
define('APP_ENV', 'production');
