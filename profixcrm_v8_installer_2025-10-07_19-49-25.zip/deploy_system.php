<?php
/**
 * 🚀 PROFIXCRM - SISTEMA DE DESPLIEGUE PROFESIONAL
 * Sistema completo de instalación y configuración automática
 * 
 * @version 1.0.0
 * @author ProfixCRM Team
 */

// Prevenir acceso directo si no es desde CLI o web autorizada
if (php_sapi_name() !== 'cli' && !isset($_SERVER['HTTP_HOST'])) {
    die('Acceso no autorizado');
}

// Configuración de errores para desarrollo
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

// Definir constantes del sistema
define('DEPLOYMENT_VERSION', '1.0.0');
define('DEPLOYMENT_START_TIME', microtime(true));
define('DEPLOYMENT_LOG_DIR', __DIR__ . '/logs/deployment');
define('DEPLOYMENT_BACKUP_DIR', __DIR__ . '/backups/deployment');
define('PROFIXCRM_MIN_PHP_VERSION', '8.0');
define('PROFIXCRM_MIN_MYSQL_VERSION', '5.7');

// Crear directorios necesarios
@mkdir(DEPLOYMENT_LOG_DIR, 0755, true);
@mkdir(DEPLOYMENT_BACKUP_DIR, 0755, true);

/**
 * 🎯 CLASE PRINCIPAL DEL SISTEMA DE DESPLIEGUE
 */
class ProfixCRMDeploymentSystem {
    
    private $logger;
    private $serverChecker;
    private $databaseInstaller;
    private $testSuite;
    private $webConfigurator;
    private $deploymentId;
    private $isCli;
    private $results = [];
    
    public function __construct() {
        $this->deploymentId = uniqid('deploy_');
        $this->isCli = php_sapi_name() === 'cli';
        $this->initializeComponents();
        $this->logDeploymentStart();
    }
    
    /**
     * Inicializar componentes del sistema
     */
    private function initializeComponents() {
        // Inicializar logger
        $this->logger = new DeploymentLogger($this->deploymentId);
        
        // Inicializar verificadores
        $this->serverChecker = new ServerChecker($this->logger);
        $this->databaseInstaller = new DatabaseInstaller($this->logger);
        $this->testSuite = new TestSuite($this->logger);
        $this->webConfigurator = new WebServerConfigurator($this->logger);
        
        $this->logger->info('Componentes del sistema inicializados');
    }
    
    /**
     * Registrar inicio del despliegue
     */
    private function logDeploymentStart() {
        $this->logger->info('=== INICIANDO DESPLIEGUE PROFIXCRM ===');
        $this->logger->info('ID de Despliegue: ' . $this->deploymentId);
        $this->logger->info('Fecha: ' . date('Y-m-d H:i:s'));
        $this->logger->info('PHP Version: ' . PHP_VERSION);
        $this->logger->info('Sistema Operativo: ' . PHP_OS);
    }
    
    /**
     * Ejecutar despliegue completo
     */
    public function deploy($config = []) {
        try {
            $this->logger->info('Iniciando proceso de despliegue...');
            
            // Fase 1: Verificación del servidor
            $this->results['server_check'] = $this->checkServerRequirements();
            if (!$this->results['server_check']['success']) {
                throw new Exception('Requisitos del servidor no cumplidos');
            }
            
            // Fase 2: Configuración de la base de datos
            $this->results['database_setup'] = $this->setupDatabase($config);
            if (!$this->results['database_setup']['success']) {
                throw new Exception('Error en configuración de base de datos');
            }
            
            // Fase 3: Configuración del servidor web
            $this->results['webserver_config'] = $this->configureWebServer();
            if (!$this->results['webserver_config']['success']) {
                throw new Exception('Error en configuración del servidor web');
            }
            
            // Fase 4: Configuración de archivos y permisos
            $this->results['files_setup'] = $this->setupFilesAndPermissions();
            if (!$this->results['files_setup']['success']) {
                throw new Exception('Error en configuración de archivos');
            }
            
            // Fase 5: Pruebas del sistema
            $this->results['tests'] = $this->runSystemTests();
            if (!$this->results['tests']['success']) {
                throw new Exception('Pruebas del sistema fallidas');
            }
            
            // Fase 6: Verificación final
            $this->results['final_verification'] = $this->finalVerification();
            
            $this->logger->info('=== DESPLIEGUE COMPLETADO EXITOSAMENTE ===');
            
            return [
                'success' => true,
                'deployment_id' => $this->deploymentId,
                'results' => $this->results,
                'duration' => $this->getDeploymentDuration()
            ];
            
        } catch (Exception $e) {
            $this->logger->error('Error en despliegue: ' . $e->getMessage());
            
            return [
                'success' => false,
                'deployment_id' => $this->deploymentId,
                'error' => $e->getMessage(),
                'results' => $this->results,
                'duration' => $this->getDeploymentDuration()
            ];
        }
    }
    
    /**
     * Verificar requisitos del servidor
     */
    private function checkServerRequirements() {
        $this->logger->info('Verificando requisitos del servidor...');
        return $this->serverChecker->checkAllRequirements();
    }
    
    /**
     * Configurar base de datos
     */
    private function setupDatabase($config) {
        $this->logger->info('Configurando base de datos...');
        
        // Obtener configuración de DB
        $dbConfig = $config['database'] ?? $this->getDatabaseConfigFromUser();
        
        return $this->databaseInstaller->setupDatabase($dbConfig);
    }
    
    /**
     * Configurar servidor web
     */
    private function configureWebServer() {
        $this->logger->info('Configurando servidor web...');
        return $this->webConfigurator->configureServer();
    }
    
    /**
     * Configurar archivos y permisos
     */
    private function setupFilesAndPermissions() {
        $this->logger->info('Configurando archivos y permisos...');
        
        $results = [
            'success' => true,
            'details' => []
        ];
        
        try {
            // Crear directorios necesarios
            $directories = [
                'storage/cache',
                'storage/logs',
                'storage/sessions',
                'storage/uploads',
                'temp',
                'logs',
                'backups'
            ];
            
            foreach ($directories as $dir) {
                $path = dirname(__DIR__) . '/' . $dir;
                if (!is_dir($path)) {
                    if (!mkdir($path, 0755, true)) {
                        throw new Exception("No se pudo crear directorio: $dir");
                    }
                    $results['details'][] = "Directorio creado: $dir";
                }
            }
            
            // Establecer permisos
            $this->setCorrectPermissions();
            
            // Copiar archivos de configuración si no existen
            $this->setupConfigurationFiles();
            
        } catch (Exception $e) {
            $results['success'] = false;
            $results['error'] = $e->getMessage();
        }
        
        return $results;
    }
    
    /**
     * Ejecutar pruebas del sistema
     */
    private function runSystemTests() {
        $this->logger->info('Ejecutando pruebas del sistema...');
        return $this->testSuite->runAllTests();
    }
    
    /**
     * Verificación final
     */
    private function finalVerification() {
        $this->logger->info('Realizando verificación final...');
        
        $results = [
            'success' => true,
            'details' => []
        ];
        
        try {
            // Verificar conexión a BD
            if (!$this->databaseInstaller->testConnection()) {
                throw new Exception('No se puede conectar a la base de datos');
            }
            $results['details'][] = 'Conexión a BD verificada';
            
            // Verificar archivos críticos
            $criticalFiles = [
                'index.php',
                'config/config.php',
                'src/Core/Config.php',
                'api/index.php'
            ];
            
            foreach ($criticalFiles as $file) {
                if (!file_exists(dirname(__DIR__) . '/' . $file)) {
                    throw new Exception("Archivo crítico faltante: $file");
                }
            }
            $results['details'][] = 'Archivos críticos verificados';
            
            // Verificar permisos de escritura
            $writablePaths = ['storage/cache', 'storage/logs', 'temp'];
            foreach ($writablePaths as $path) {
                $fullPath = dirname(__DIR__) . '/' . $path;
                if (!is_writable($fullPath)) {
                    throw new Exception("Sin permisos de escritura en: $path");
                }
            }
            $results['details'][] = 'Permisos de escritura verificados';
            
        } catch (Exception $e) {
            $results['success'] = false;
            $results['error'] = $e->getMessage();
        }
        
        return $results;
    }
    
    /**
     * Establecer permisos correctos
     */
    private function setCorrectPermissions() {
        $rootPath = dirname(__DIR__);
        
        // Permisos para archivos PHP
        $phpFiles = glob($rootPath . '/*.php');
        foreach ($phpFiles as $file) {
            chmod($file, 0644);
        }
        
        // Permisos para directorios de almacenamiento
        $storageDirs = ['storage', 'temp', 'logs', 'backups'];
        foreach ($storageDirs as $dir) {
            $path = $rootPath . '/' . $dir;
            if (is_dir($path)) {
                chmod($path, 0755);
            }
        }
        
        $this->logger->info('Permisos establecidos correctamente');
    }
    
    /**
     * Configurar archivos de configuración
     */
    private function setupConfigurationFiles() {
        $rootPath = dirname(__DIR__);
        
        // Verificar archivo .env
        if (!file_exists($rootPath . '/.env')) {
            copy($rootPath . '/.env.example', $rootPath . '/.env');
            $this->logger->info('Archivo .env creado desde ejemplo');
        }
        
        // Verificar configuración
        if (!file_exists($rootPath . '/config/config.php')) {
            // Crear configuración básica
            $this->createBasicConfig();
        }
    }
    
    /**
     * Crear configuración básica
     */
    private function createBasicConfig() {
        $configContent = <<<'PHP'
<?php
/**
 * Configuración básica de ProfixCRM
 * Generada automáticamente por el sistema de despliegue
 */

return [
    'app' => [
        'name' => 'ProfixCRM',
        'version' => '8.0.0',
        'environment' => 'production',
        'debug' => false,
        'timezone' => 'America/Mexico_City',
        'locale' => 'es_MX',
    ],
    
    'database' => [
        'driver' => 'mysql',
        'host' => $_ENV['DB_HOST'] ?? 'localhost',
        'port' => $_ENV['DB_PORT'] ?? '3306',
        'database' => $_ENV['DB_NAME'] ?? 'profixcrm',
        'username' => $_ENV['DB_USER'] ?? 'root',
        'password' => $_ENV['DB_PASS'] ?? '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
    ],
    
    'security' => [
        'jwt_secret' => $_ENV['JWT_SECRET'] ?? bin2hex(random_bytes(32)),
        'encryption_key' => $_ENV['ENCRYPTION_KEY'] ?? bin2hex(random_bytes(32)),
        'session_lifetime' => 120,
        'password_timeout' => 3600,
    ],
    
    'mail' => [
        'driver' => 'smtp',
        'host' => $_ENV['MAIL_HOST'] ?? 'smtp.gmail.com',
        'port' => $_ENV['MAIL_PORT'] ?? '587',
        'encryption' => 'tls',
        'username' => $_ENV['MAIL_USER'] ?? '',
        'password' => $_ENV['MAIL_PASS'] ?? '',
    ],
];
PHP;
        
        file_put_contents(dirname(__DIR__) . '/config/config.php', $configContent);
        $this->logger->info('Configuración básica creada');
    }
    
    /**
     * Obtener duración del despliegue
     */
    private function getDeploymentDuration() {
        return round(microtime(true) - DEPLOYMENT_START_TIME, 2);
    }
    
    /**
     * Obtener configuración de BD del usuario (para CLI)
     */
    private function getDatabaseConfigFromUser() {
        if ($this->isCli) {
            echo "\n=== CONFIGURACIÓN DE BASE DE DATOS ===\n";
            echo "Host [localhost]: ";
            $host = trim(fgets(STDIN)) ?: 'localhost';
            
            echo "Puerto [3306]: ";
            $port = trim(fgets(STDIN)) ?: '3306';
            
            echo "Base de datos: ";
            $database = trim(fgets(STDIN));
            
            echo "Usuario: ";
            $username = trim(fgets(STDIN));
            
            echo "Contraseña: ";
            system('stty -echo');
            $password = trim(fgets(STDIN));
            system('stty echo');
            echo "\n";
            
            return [
                'host' => $host,
                'port' => $port,
                'database' => $database,
                'username' => $username,
                'password' => $password
            ];
        }
        
        return [];
    }
    
    /**
     * Renderizar interfaz web
     */
    public function renderWebInterface() {
        ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🚀 ProfixCRM - Sistema de Despliegue</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .header p {
            font-size: 1.2em;
            opacity: 0.9;
        }
        
        .deployment-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #555;
        }
        
        .form-group input, .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }
        
        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s ease;
            margin-right: 10px;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }
        
        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        
        .progress-container {
            margin: 30px 0;
            display: none;
        }
        
        .progress-bar {
            width: 100%;
            height: 8px;
            background: #e1e5e9;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            width: 0%;
            transition: width 0.3s ease;
        }
        
        .progress-text {
            text-align: center;
            margin-top: 10px;
            font-weight: 600;
            color: #667eea;
        }
        
        .results {
            margin-top: 30px;
            display: none;
        }
        
        .result-item {
            background: #f8f9fa;
            border-left: 4px solid #28a745;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
        }
        
        .result-item.error {
            border-left-color: #dc3545;
            background: #fff5f5;
        }
        
        .result-item.warning {
            border-left-color: #ffc107;
            background: #fffaf0;
        }
        
        .result-title {
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .result-details {
            font-size: 14px;
            color: #666;
        }
        
        .logs {
            background: #2d3748;
            color: #e2e8f0;
            padding: 20px;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            max-height: 400px;
            overflow-y: auto;
            margin-top: 20px;
        }
        
        .log-entry {
            margin-bottom: 5px;
            padding: 2px 0;
        }
        
        .log-entry.error {
            color: #fc8181;
        }
        
        .log-entry.success {
            color: #68d391;
        }
        
        .log-entry.info {
            color: #63b3ed;
        }
        
        .error-fix {
            background: #fed7d7;
            border: 1px solid #feb2b2;
            border-radius: 5px;
            padding: 15px;
            margin-top: 10px;
        }
        
        .error-fix h4 {
            color: #c53030;
            margin-bottom: 10px;
        }
        
        .error-fix code {
            background: #fff5f5;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
        }
        
        .success-message {
            background: #c6f6d5;
            border: 1px solid #9ae6b4;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            margin-top: 20px;
        }
        
        .success-message h3 {
            color: #22543d;
            margin-bottom: 10px;
        }
        
        .success-message p {
            color: #2f855a;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            
            .deployment-card {
                padding: 20px;
            }
            
            .header h1 {
                font-size: 2em;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 ProfixCRM Deployment System</h1>
            <p>Sistema profesional de instalación y configuración automática</p>
        </div>
        
        <div class="deployment-card">
            <h2>⚙️ Configuración de Despliegue</h2>
            <p>Completa la siguiente información para instalar ProfixCRM en tu servidor:</p>
            
            <form id="deploymentForm">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    
                    <!-- Configuración de Base de Datos -->
                    <div>
                        <h3 style="margin-bottom: 15px; color: #667eea;">🗄️ Base de Datos</h3>
                        
                        <div class="form-group">
                            <label for="db_action">Acción de Base de Datos:</label>
                            <select id="db_action" name="db_action" required>
                                <option value="create">Crear nueva base de datos</option>
                                <option value="connect">Conectar a base de datos existente</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="db_host">Host:</label>
                            <input type="text" id="db_host" name="db_host" value="localhost" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="db_port">Puerto:</label>
                            <input type="number" id="db_port" name="db_port" value="3306" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="db_name">Nombre de Base de Datos:</label>
                            <input type="text" id="db_name" name="db_name" value="profixcrm" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="db_user">Usuario:</label>
                            <input type="text" id="db_user" name="db_user" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="db_pass">Contraseña:</label>
                            <input type="password" id="db_pass" name="db_pass">
                        </div>
                    </div>
                    
                    <!-- Configuración del Sistema -->
                    <div>
                        <h3 style="margin-bottom: 15px; color: #667eea;">⚙️ Configuración del Sistema</h3>
                        
                        <div class="form-group">
                            <label for="app_name">Nombre de la Aplicación:</label>
                            <input type="text" id="app_name" name="app_name" value="ProfixCRM" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="app_url">URL de la Aplicación:</label>
                            <input type="url" id="app_url" name="app_url" value="<?php echo 'http://' . $_SERVER['HTTP_HOST']; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="admin_email">Email del Administrador:</label>
                            <input type="email" id="admin_email" name="admin_email" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="admin_password">Contraseña del Administrador:</label>
                            <input type="password" id="admin_password" name="admin_password" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="timezone">Zona Horaria:</label>
                            <select id="timezone" name="timezone" required>
                                <option value="America/Mexico_City">America/Mexico_City</option>
                                <option value="America/New_York">America/New_York</option>
                                <option value="America/Los_Angeles">America/Los_Angeles</option>
                                <option value="Europe/Madrid">Europe/Madrid</option>
                                <option value="UTC">UTC</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="web_server">Servidor Web:</label>
                            <select id="web_server" name="web_server" required>
                                <option value="auto">Detectar automáticamente</option>
                                <option value="apache">Apache</option>
                                <option value="nginx">Nginx</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                    <button type="submit" class="btn" id="deployBtn">
                        🚀 Iniciar Despliegue
                    </button>
                    <button type="button" class="btn" onclick="runDiagnostics()" style="background: #28a745;">
                        🔍 Ejecutar Diagnóstico
                    </button>
                </div>
            </form>
        </div>
        
        <!-- Barra de Progreso -->
        <div class="deployment-card progress-container" id="progressContainer">
            <h3>🔄 Procesando Despliegue...</h3>
            <div class="progress-bar">
                <div class="progress-fill" id="progressFill"></div>
            </div>
            <div class="progress-text" id="progressText">Iniciando...</div>
            <div class="logs" id="deploymentLogs"></div>
        </div>
        
        <!-- Resultados -->
        <div class="deployment-card results" id="resultsContainer">
            <h3>📊 Resultados del Despliegue</h3>
            <div id="resultsContent"></div>
        </div>
    </div>
    
    <script>
        let deploymentActive = false;
        let logInterval = null;
        
        // Manejar envío del formulario
        document.getElementById('deploymentForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (deploymentActive) return;
            
            // Validar formulario
            if (!validateForm()) {
                return;
            }
            
            // Iniciar despliegue
            startDeployment();
        });
        
        // Validar formulario
        function validateForm() {
            const form = document.getElementById('deploymentForm');
            const requiredFields = form.querySelectorAll('[required]');
            let valid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.style.borderColor = '#dc3545';
                    valid = false;
                } else {
                    field.style.borderColor = '#e1e5e9';
                }
            });
            
            if (!valid) {
                alert('Por favor completa todos los campos requeridos.');
            }
            
            return valid;
        }
        
        // Iniciar despliegue
        function startDeployment() {
            deploymentActive = true;
            
            // Deshabilitar botón
            document.getElementById('deployBtn').disabled = true;
            document.getElementById('deployBtn').textContent = '🔄 Desplegando...';
            
            // Mostrar progreso
            document.getElementById('progressContainer').style.display = 'block';
            document.getElementById('resultsContainer').style.display = 'none';
            
            // Obtener datos del formulario
            const formData = new FormData(document.getElementById('deploymentForm'));
            const config = Object.fromEntries(formData.entries());
            
            // Iniciar logs en tiempo real
            startLogMonitoring();
            
            // Enviar petición AJAX
            fetch('deploy_system.php?action=deploy', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ config: config })
            })
            .then(response => response.json())
            .then(data => {
                deploymentActive = false;
                stopLogMonitoring();
                
                // Mostrar resultados
                displayResults(data);
                
                // Restaurar botón
                document.getElementById('deployBtn').disabled = false;
                document.getElementById('deployBtn').textContent = '🚀 Iniciar Despliegue';
            })
            .catch(error => {
                deploymentActive = false;
                stopLogMonitoring();
                
                console.error('Error:', error);
                alert('Error en el despliegue: ' + error.message);
                
                // Restaurar botón
                document.getElementById('deployBtn').disabled = false;
                document.getElementById('deployBtn').textContent = '🚀 Iniciar Despliegue';
            });
        }
        
        // Monitorear logs en tiempo real
        function startLogMonitoring() {
            logInterval = setInterval(() => {
                fetch('deploy_system.php?action=getLogs&deployment_id=<?php echo $this->deploymentId; ?>')
                    .then(response => response.json())
                    .then(data => {
                        if (data.logs && data.logs.length > 0) {
                            const logsContainer = document.getElementById('deploymentLogs');
                            data.logs.forEach(log => {
                                const logEntry = document.createElement('div');
                                logEntry.className = 'log-entry ' + log.level;
                                logEntry.textContent = `[${log.timestamp}] ${log.message}`;
                                logsContainer.appendChild(logEntry);
                            });
                            logsContainer.scrollTop = logsContainer.scrollHeight;
                            
                            // Actualizar progreso
                            if (data.progress) {
                                updateProgress(data.progress);
                            }
                        }
                    })
                    .catch(error => {
                        console.error('Error obteniendo logs:', error);
                    });
            }, 1000);
        }
        
        // Detener monitoreo de logs
        function stopLogMonitoring() {
            if (logInterval) {
                clearInterval(logInterval);
                logInterval = null;
            }
        }
        
        // Actualizar barra de progreso
        function updateProgress(progress) {
            const progressFill = document.getElementById('progressFill');
            const progressText = document.getElementById('progressText');
            
            progressFill.style.width = progress.percentage + '%';
            progressText.textContent = progress.phase + ' - ' + progress.percentage + '%';
        }
        
        // Mostrar resultados
        function displayResults(data) {
            const resultsContainer = document.getElementById('resultsContainer');
            const resultsContent = document.getElementById('resultsContent');
            
            resultsContainer.style.display = 'block';
            
            let html = '';
            
            if (data.success) {
                html += `
                    <div class="success-message">
                        <h3>🎉 ¡Despliegue Exitoso!</h3>
                        <p>ProfixCRM ha sido instalado correctamente.</p>
                        <p><strong>Duración:</strong> ${data.duration} segundos</p>
                        <p><strong>ID de Despliegue:</strong> ${data.deployment_id}</p>
                    </div>
                `;
            } else {
                html += `
                    <div class="result-item error">
                        <div class="result-title">❌ Error en el Despliegue</div>
                        <div class="result-details">${data.error}</div>
                    </div>
                `;
            }
            
            // Mostrar detalles de cada fase
            if (data.results) {
                html += '<h4 style="margin: 20px 0 10px 0;">Detalles del Proceso:</h4>';
                
                Object.entries(data.results).forEach(([phase, result]) => {
                    const statusClass = result.success ? 'success' : 'error';
                    const statusIcon = result.success ? '✅' : '❌';
                    
                    html += `
                        <div class="result-item ${statusClass}">
                            <div class="result-title">${statusIcon} ${getPhaseName(phase)}</div>
                            <div class="result-details">
                                ${result.success ? 'Completado exitosamente' : (result.error || 'Error desconocido')}
                            </div>
                            ${result.details ? '<div class="result-details"><strong>Detalles:</strong> ' + result.details.join(', ') + '</div>' : ''}
                        </div>
                    `;
                });
            }
            
            // Mostrar correcciones si hay errores
            if (!data.success && data.results) {
                const fixes = generateErrorFixes(data.results);
                if (fixes.length > 0) {
                    html += `
                        <div class="error-fix">
                            <h4>🔧 Sugerencias de Corrección:</h4>
                            ${fixes.map(fix => `<p>• ${fix}</p>`).join('')}
                        </div>
                    `;
                }
            }
            
            resultsContent.innerHTML = html;
            
            // Scroll a resultados
            resultsContainer.scrollIntoView({ behavior: 'smooth' });
        }
        
        // Obtener nombre amigable de la fase
        function getPhaseName(phase) {
            const names = {
                'server_check': 'Verificación del Servidor',
                'database_setup': 'Configuración de Base de Datos',
                'webserver_config': 'Configuración del Servidor Web',
                'files_setup': 'Configuración de Archivos',
                'tests': 'Pruebas del Sistema',
                'final_verification': 'Verificación Final'
            };
            return names[phase] || phase;
        }
        
        // Generar sugerencias de corrección
        function generateErrorFixes(results) {
            const fixes = [];
            
            if (results.server_check && !results.server_check.success) {
                fixes.push('Verifica que PHP 8.0+ esté instalado y las extensiones requeridas estén habilitadas.');
            }
            
            if (results.database_setup && !results.database_setup.success) {
                fixes.push('Verifica las credenciales de MySQL y que el servidor esté ejecutándose.');
            }
            
            if (results.files_setup && !results.files_setup.success) {
                fixes.push('Verifica los permisos de escritura en los directorios del sistema.');
            }
            
            return fixes;
        }
        
        // Ejecutar diagnóstico
        function runDiagnostics() {
            alert('Ejecutando diagnóstico del sistema...');
            // Implementar diagnóstico rápido
        }
    </script>
</body>
</html>
        <?php
    }
}

// ===== IMPLEMENTACIÓN DE CLASES AUXILIARES =====

/**
 * 📋 Sistema de Logging
 */
class DeploymentLogger {
    private $deploymentId;
    private $logFile;
    
    public function __construct($deploymentId) {
        $this->deploymentId = $deploymentId;
        $this->logFile = DEPLOYMENT_LOG_DIR . '/' . $deploymentId . '.log';
    }
    
    public function info($message) {
        $this->log('INFO', $message);
    }
    
    public function error($message) {
        $this->log('ERROR', $message);
    }
    
    public function warning($message) {
        $this->log('WARNING', $message);
    }
    
    public function success($message) {
        $this->log('SUCCESS', $message);
    }
    
    private function log($level, $message) {
        $timestamp = date('Y-m-d H:i:s');
        $logEntry = "[$timestamp] [$level] $message" . PHP_EOL;
        
        // Guardar en archivo
        file_put_contents($this->logFile, $logEntry, FILE_APPEND | LOCK_EX);
        
        // También mostrar en consola si es CLI
        if (php_sapi_name() === 'cli') {
            echo $logEntry;
        }
    }
    
    public function getLogs($limit = 100) {
        if (!file_exists($this->logFile)) {
            return [];
        }
        
        $logs = file($this->logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $recentLogs = array_slice($logs, -$limit);
        
        $parsedLogs = [];
        foreach ($recentLogs as $log) {
            if (preg_match('/\[(.*?)\] \[(.*?)\] (.*)/', $log, $matches)) {
                $parsedLogs[] = [
                    'timestamp' => $matches[1],
                    'level' => strtolower($matches[2]),
                    'message' => $matches[3]
                ];
            }
        }
        
        return $parsedLogs;
    }
}

/**
 * 🔍 Placeholder para ServerChecker (se implementará después)
 */
class ServerChecker {
    private $logger;
    
    public function __construct($logger) {
        $this->logger = $logger;
    }
    
    public function checkAllRequirements() {
        // Implementación vendrá después
        return ['success' => true, 'details' => ['Requisitos básicos verificados']];
    }
}

/**
 * 🗄️ Placeholder para DatabaseInstaller
 */
class DatabaseInstaller {
    private $logger;
    
    public function __construct($logger) {
        $this->logger = $logger;
    }
    
    public function setupDatabase($config) {
        // Implementación vendrá después
        return ['success' => true, 'details' => ['Base de datos configurada']];
    }
    
    public function testConnection() {
        return true;
    }
}

/**
 * 🧪 Placeholder para TestSuite
 */
class TestSuite {
    private $logger;
    
    public function __construct($logger) {
        $this->logger = $logger;
    }
    
    public function runAllTests() {
        // Implementación vendrá después
        return ['success' => true, 'details' => ['Todas las pruebas pasaron']];
    }
}

/**
 * 🌐 Placeholder para WebServerConfigurator
 */
class WebServerConfigurator {
    private $logger;
    
    public function __construct($logger) {
        $this->logger = $logger;
    }
    
    public function configureServer() {
        // Implementación vendrá después
        return ['success' => true, 'details' => ['Servidor web configurado']];
    }
}

// ===== MANEJADOR DE PETICIONES =====

// Manejar peticiones AJAX
if (isset($_GET['action'])) {
    header('Content-Type: application/json');
    
    switch ($_GET['action']) {
        case 'deploy':
            $input = json_decode(file_get_contents('php://input'), true);
            $deployment = new ProfixCRMDeploymentSystem();
            $result = $deployment->deploy($input['config'] ?? []);
            echo json_encode($result);
            break;
            
        case 'getLogs':
            $deploymentId = $_GET['deployment_id'] ?? '';
            $logger = new DeploymentLogger($deploymentId);
            echo json_encode([
                'logs' => $logger->getLogs(50),
                'progress' => getDeploymentProgress($deploymentId)
            ]);
            break;
            
        default:
            echo json_encode(['error' => 'Acción no válida']);
    }
    exit;
}

// Función auxiliar para obtener progreso
function getDeploymentProgress($deploymentId) {
    // Implementar lógica de progreso
    return [
        'percentage' => rand(10, 90),
        'phase' => 'Configurando sistema'
    ];
}

// Si no es petición AJAX, mostrar interfaz web
$deployment = new ProfixCRMDeploymentSystem();
$deployment->renderWebInterface();