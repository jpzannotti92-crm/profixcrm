<?php
// Test para verificar el tipo MIME del archivo
require_once '../../config/database.php';
require_once 'database.php';

// Crear un archivo temporal real con contenido CSV
$tempFile = tempnam(sys_get_temp_dir(), 'csv_test_');
$csvContent = "first_name,last_name,email\n";
$csvContent .= "Juan,Pérez,juan.perez@test.com\n";
$csvContent .= "María,García,maria.garcia@test.com\n";

file_put_contents($tempFile, $csvContent);

echo "=== Test de Detección MIME ===\n\n";

// Detectar tipo MIME
$fileInfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($fileInfo, $tempFile);
finfo_close($fileInfo);

echo "Archivo temporal: " . basename($tempFile) . "\n";
echo "Tipo MIME detectado: " . $mimeType . "\n";
echo "Tamaño: " . filesize($tempFile) . " bytes\n";

$allowedTypes = ['text/csv', 'application/vnd.ms-excel', 'text/plain'];
echo "¿Es tipo permitido? " . (in_array($mimeType, $allowedTypes) ? 'Sí' : 'No') . "\n";

// También probar con el nombre del archivo
$extension = pathinfo($tempFile, PATHINFO_EXTENSION);
echo "Extensión: " . $extension . "\n";

// Limpiar
unlink($tempFile);

echo "\n=== Test completado ===\n";
?>