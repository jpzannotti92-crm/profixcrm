<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Simular exactamente lo que hace axios desde el frontend
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'http://localhost:8000/api/api/auth/login.php');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'username' => 'admin',
    'password' => 'admin123',
    'remember' => false
]));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Accept: application/json'
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);

$headers = substr($response, 0, $headerSize);
$body = substr($response, $headerSize);

curl_close($ch);

echo "=== TEST REAL FRONTEND (CURL) ===\n\n";
echo "HTTP Code: $httpCode\n";
echo "Headers:\n$headers\n";
echo "Body:\n$body\n\n";

$decoded = json_decode($body, true);
if ($decoded) {
    echo "📋 Análisis de respuesta:\n";
    echo "- Success: " . ($decoded['success'] ? 'true' : 'false') . "\n";
    echo "- Message: " . ($decoded['message'] ?? 'no message') . "\n";
    echo "- Token presente: " . (isset($decoded['token']) ? 'SÍ' : 'NO') . "\n";
    echo "- User presente: " . (isset($decoded['user']) ? 'SÍ' : 'NO') . "\n";
    
    if (isset($decoded['user'])) {
        echo "- User ID: " . ($decoded['user']['id'] ?? 'no id') . "\n";
        echo "- Username: " . ($decoded['user']['username'] ?? 'no username') . "\n";
        echo "- First name: " . ($decoded['user']['first_name'] ?? 'no first_name') . "\n";
    }
    
    echo "\n🎯 RESULTADO: ";
    if ($decoded['success'] && isset($decoded['token']) && isset($decoded['user'])) {
        echo "LOGIN EXITOSO - El frontend debería funcionar\n";
    } else {
        echo "LOGIN FALLIDO - Revisar respuesta\n";
    }
} else {
    echo "❌ Error decodificando JSON\n";
    echo "JSON Error: " . json_last_error_msg() . "\n";
}
?>