<?php
// Test más realista para el nuevo endpoint de importación
require_once '../../config/database.php';
require_once 'database.php';

echo "=== Test de Importación Realista ===\n\n";

// Crear un archivo temporal real
$tempFile = tempnam(sys_get_temp_dir(), 'csv_test_');
$csvContent = "first_name,last_name,email,phone,country,city,company,job_title,source,campaign,status,priority,value\n";
$csvContent .= "Juan,Pérez,juan.perez@test.com,5551234567,México,Ciudad de México,Tech Corp,Vendedor,Website,Campaign 1,new,high,1000\n";
$csvContent .= "María,García,maria.garcia@test.com,5552345678,España,Madrid,Marketing SA,Marketing Manager,Facebook,Campaign 2,new,medium,2500\n";
$csvContent .= "Carlos,López,carlos.lopez@test.com,5553456789,Colombia,Bogotá,Finance Ltd,Analista,Google,Campaign 3,contacted,high,5000\n";

file_put_contents($tempFile, $csvContent);

// Simular una petición POST con archivo real
$_SERVER['REQUEST_METHOD'] = 'POST';
$_FILES['file'] = [
    'name' => 'test_leads.csv',
    'type' => 'text/csv',
    'tmp_name' => $tempFile,
    'error' => UPLOAD_ERR_OK,
    'size' => filesize($tempFile)
];

echo "1. Probando primera fase (sin mapeo):\n";
echo "   - Archivo temporal: " . basename($tempFile) . "\n";
echo "   - Tamaño: " . $_FILES['file']['size'] . " bytes\n";

// No enviar mapeo para probar la primera fase
$_POST['mapping'] = null;

// Incluir el archivo para ejecutar la lógica
ob_start();
include 'import-simple.php';
$output = ob_get_clean();

$result = json_decode($output, true);
if ($result && isset($result['success'])) {
    echo "   - Resultado: ÉXITO\n";
    echo "   - Columnas encontradas: " . implode(', ', $result['data']['columns']) . "\n";
    echo "   - Total filas: " . $result['data']['total_rows'] . "\n";
    echo "   - Requiere mapeo: " . ($result['data']['requires_mapping'] ? 'Sí' : 'No') . "\n";
    
    // Ahora probar con mapeo
    echo "\n2. Probando segunda fase (con mapeo):\n";
    
    // Crear mapeo simple
    $mapping = [
        'first_name' => 'first_name',
        'last_name' => 'last_name',
        'email' => 'email',
        'phone' => 'phone',
        'country' => 'country',
        'city' => 'city',
        'company' => 'company',
        'job_title' => 'job_title',
        'source' => 'source',
        'campaign' => 'campaign',
        'status' => 'status',
        'priority' => 'priority',
        'value' => 'value'
    ];
    
    $_POST['mapping'] = json_encode($mapping);
    
    // Reiniciar el archivo
    file_put_contents($tempFile, $csvContent);
    
    ob_start();
    include 'import-simple.php';
    $output2 = ob_get_clean();
    
    $result2 = json_decode($output2, true);
    if ($result2 && isset($result2['success'])) {
        echo "   - Resultado: ÉXITO\n";
        echo "   - Importados: " . ($result2['data']['imported'] ?? 0) . "\n";
        echo "   - Duplicados: " . ($result2['data']['duplicates'] ?? 0) . "\n";
        echo "   - Errores: " . ($result2['data']['errors'] ?? 0) . "\n";
        
        if (isset($result2['data']['errors_list']) && count($result2['data']['errors_list']) > 0) {
            echo "   - Lista de errores:\n";
            foreach ($result2['data']['errors_list'] as $error) {
                echo "     * " . $error . "\n";
            }
        }
    } else {
        echo "   - Resultado: ERROR\n";
        echo "   - Mensaje: " . ($result2['message'] ?? 'Desconocido') . "\n";
        echo "   - Output raw: " . $output2 . "\n";
    }
    
} else {
    echo "   - Resultado: ERROR\n";
    echo "   - Mensaje: " . ($result['message'] ?? 'Desconocido') . "\n";
    echo "   - Output raw: " . $output . "\n";
}

echo "\n3. Verificando funciones:\n";
echo "   - processCSV existe: " . (function_exists('processCSV') ? 'Sí' : 'No') . "\n";
echo "   - mapRowToLead existe: " . (function_exists('mapRowToLead') ? 'Sí' : 'No') . "\n";

// Limpiar
unlink($tempFile);

echo "\n=== Test completado ===\n";
?>