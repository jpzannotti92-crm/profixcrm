<?php
echo "API Test - Server is working!";
echo "\n";
echo "Request URI: " . $_SERVER['REQUEST_URI'];
echo "\n";
echo "Method: " . $_SERVER['REQUEST_METHOD'];
?>