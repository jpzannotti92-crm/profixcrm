<?php
// Test para probar el nuevo endpoint de importación
require_once '../../config/database.php';
require_once 'database.php';

echo "=== Test de Importación Simple ===\n\n";

// Simular una petición POST con archivo
$_SERVER['REQUEST_METHOD'] = 'POST';
$_FILES['file'] = [
    'name' => 'test_leads_simple.csv',
    'type' => 'text/csv',
    'tmp_name' => 'test_leads_simple.csv',
    'error' => UPLOAD_ERR_OK,
    'size' => filesize('test_leads_simple.csv')
];

// No enviar mapeo para probar la primera fase
$_POST['mapping'] = null;

echo "1. Probando primera fase (sin mapeo):\n";
echo "   - Archivo: test_leads_simple.csv\n";
echo "   - Tamaño: " . $_FILES['file']['size'] . " bytes\n";

// Incluir el archivo para ejecutar la lógica
ob_start();
include 'import-simple.php';
$output = ob_get_clean();

$result = json_decode($output, true);
if ($result && isset($result['success'])) {
    echo "   - Resultado: ÉXITO\n";
    echo "   - Columnas encontradas: " . implode(', ', $result['data']['columns']) . "\n";
    echo "   - Total filas: " . $result['data']['total_rows'] . "\n";
    echo "   - Requiere mapeo: " . ($result['data']['requires_mapping'] ? 'Sí' : 'No') . "\n";
} else {
    echo "   - Resultado: ERROR\n";
    echo "   - Mensaje: " . ($result['message'] ?? 'Desconocido') . "\n";
    echo "   - Output raw: " . $output . "\n";
}

echo "\n2. Verificando funciones:\n";
echo "   - processCSV existe: " . (function_exists('processCSV') ? 'Sí' : 'No') . "\n";
echo "   - mapRowToLead existe: " . (function_exists('mapRowToLead') ? 'Sí' : 'No') . "\n";

echo "\n=== Test completado ===\n";
?>