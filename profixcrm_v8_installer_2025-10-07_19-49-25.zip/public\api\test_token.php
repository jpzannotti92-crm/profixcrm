<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Cargar autoloader de Composer
require_once '../../vendor/autoload.php';

// Cargar variables de entorno
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../../');
$dotenv->load();

// Cargar archivos necesarios
require_once '../../src/Core/Request.php';

use IaTradeCRM\Core\Request;

$request = new Request();

// Información de debug
$debugInfo = [
    'method' => $_SERVER['REQUEST_METHOD'],
    'headers' => $request->getHeaders(),
    'auth_header' => $request->getHeader('authorization'),
    'server_auth' => $_SERVER['HTTP_AUTHORIZATION'] ?? 'No encontrado',
    'cookies' => $_COOKIE,
    'getallheaders' => function_exists('getallheaders') ? getallheaders() : 'Función no disponible'
];

// Intentar extraer token manualmente
$token = null;

// Método 1: Header Authorization del request
$authHeader = $request->getHeader('authorization');
if ($authHeader && preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
    $token = $matches[1];
    $debugInfo['token_source'] = 'Request header';
}

// Método 2: getallheaders
if (!$token && function_exists('getallheaders')) {
    $headers = getallheaders();
    if (isset($headers['Authorization'])) {
        if (preg_match('/Bearer\s+(.*)$/i', $headers['Authorization'], $matches)) {
            $token = $matches[1];
            $debugInfo['token_source'] = 'getallheaders';
        }
    }
}

// Método 3: $_SERVER
if (!$token && isset($_SERVER['HTTP_AUTHORIZATION'])) {
    if (preg_match('/Bearer\s+(.*)$/i', $_SERVER['HTTP_AUTHORIZATION'], $matches)) {
        $token = $matches[1];
        $debugInfo['token_source'] = '$_SERVER';
    }
}

// Método 4: Cookies
if (!$token && isset($_COOKIE['auth_token'])) {
    $token = $_COOKIE['auth_token'];
    $debugInfo['token_source'] = 'Cookie';
}

$debugInfo['token_found'] = $token ? 'Sí' : 'No';
$debugInfo['token_length'] = $token ? strlen($token) : 0;

echo json_encode([
    'success' => true,
    'token' => $token ? substr($token, 0, 20) . '...' : null,
    'debug' => $debugInfo
]);
?>