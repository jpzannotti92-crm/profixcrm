<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Testing database connection...\n";

try {
    require_once 'database.php';
    echo "Database.php loaded successfully\n";
    
    $pdo = getDbConnection();
    echo "Database connection successful\n";
    
    // Crear tabla de prueba
    $pdo->exec("CREATE TABLE IF NOT EXISTS test_table (id INT PRIMARY KEY, name VARCHAR(100))");
    echo "Test table created\n";
    
    // Insertar datos de prueba
    $pdo->exec("INSERT IGNORE INTO test_table (id, name) VALUES (1, 'test')");
    echo "Test data inserted\n";
    
    // Consultar datos
    $stmt = $pdo->query("SELECT * FROM test_table");
    $results = $stmt->fetchAll();
    echo "Query results: " . json_encode($results) . "\n";
    
    echo "All tests passed!\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "Stack trace: " . $e->getTraceAsString() . "\n";
}
?>