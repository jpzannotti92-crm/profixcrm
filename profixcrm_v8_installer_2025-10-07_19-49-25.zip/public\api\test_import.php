<?php
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../src/Database/Connection.php';

use iaTradeCRM\Database\Connection;

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    $db = Connection::getInstance()->getConnection();
    
    // Datos de prueba para importación
    $testLeads = [
        [
            'first_name' => 'Test',
            'last_name' => 'Import1',
            'email' => 'test1@import.com',
            'phone' => '+1234567890',
            'country' => 'España',
            'city' => 'Madrid',
            'company' => 'Test Company',
            'position' => 'Manager',
            'source' => 'Import Test',
            'status' => 'new',
            'interest_level' => 'high'
        ],
        [
            'first_name' => 'Test',
            'last_name' => 'Import2',
            'email' => 'test2@import.com',
            'phone' => '+1234567891',
            'country' => 'España',
            'city' => 'Barcelona',
            'company' => 'Test Company 2',
            'position' => 'Director',
            'source' => 'Import Test',
            'status' => 'new',
            'interest_level' => 'medium'
        ]
    ];
    
    $imported = 0;
    $errors = 0;
    $errorDetails = [];
    
    foreach ($testLeads as $index => $leadData) {
        try {
            // Insertar lead
            $stmt = $db->prepare("
                INSERT INTO leads (
                    first_name, last_name, email, phone, country, city, 
                    company, job_title, source, status, priority, 
                    value, notes, assigned_to, desk_id, created_at, updated_at
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW()
                )
            ");
            
            $result = $stmt->execute([
                $leadData['first_name'] ?? '',
                $leadData['last_name'] ?? '',
                $leadData['email'] ?? '',
                $leadData['phone'] ?? '',
                $leadData['country'] ?? '',
                $leadData['city'] ?? '',
                $leadData['company'] ?? '',
                $leadData['position'] ?? '', // Mapear position a job_title
                $leadData['source'] ?? 'Import',
                $leadData['status'] ?? 'new',
                $leadData['interest_level'] ?? 'medium', // Mapear interest_level a priority
                null, // value
                '', // notes
                null, // assigned_to
                null  // desk_id
            ]);
            
            if ($result) {
                $imported++;
                echo "Lead " . ($index + 1) . " insertado correctamente\n";
            } else {
                $errors++;
                $errorInfo = $stmt->errorInfo();
                $errorDetails[] = "Lead " . ($index + 1) . ": " . $errorInfo[2];
                echo "Error insertando lead " . ($index + 1) . ": " . $errorInfo[2] . "\n";
            }
            
        } catch (Exception $e) {
            $errors++;
            $errorDetails[] = "Lead " . ($index + 1) . ": " . $e->getMessage();
            echo "Excepción insertando lead " . ($index + 1) . ": " . $e->getMessage() . "\n";
        }
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Prueba de importación completada',
        'imported' => $imported,
        'errors' => $errors,
        'error_details' => $errorDetails,
        'total' => count($testLeads)
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error en la prueba: ' . $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>