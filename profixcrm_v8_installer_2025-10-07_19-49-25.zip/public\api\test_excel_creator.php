<?php
// Crear un archivo Excel de prueba simple (formato XLSX)
$tempFile = tempnam(sys_get_temp_dir(), 'excel_test_') . '.xlsx';

// Crear un archivo XLSX básico (es un ZIP con estructura XML)
$zip = new ZipArchive();
if ($zip->open($tempFile, ZipArchive::CREATE) === TRUE) {
    
    // Crear estructura básica de un archivo XLSX
    
    // [Content_Types].xml
    $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
    <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
    <Default Extension="xml" ContentType="application/xml"/>
    <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
    <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
    <Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
</Types>';
    $zip->addFromString('[Content_Types].xml', $contentTypes);
    
    // _rels/.rels
    $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>';
    $zip->addFromString('_rels/.rels', $rels);
    
    // xl/_rels/workbook.xml.rels
    $workbookRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
    <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>
</Relationships>';
    $zip->addFromString('xl/_rels/workbook.xml.rels', $workbookRels);
    
    // xl/workbook.xml
    $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <sheets>
        <sheet name="Hoja1" sheetId="1" r:id="rId1" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>
    </sheets>
</workbook>';
    $zip->addFromString('xl/workbook.xml', $workbook);
    
    // xl/sharedStrings.xml
    $sharedStrings = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="8" uniqueCount="8">
    <si><t>first_name</t></si>
    <si><t>last_name</t></si>
    <si><t>email</t></si>
    <si><t>phone</t></si>
    <si><t>country</t></si>
    <si><t>Juan</t></si>
    <si><t>Pérez</t></si>
    <si><t>juan.perez@test.com</t></si>
</sst>';
    $zip->addFromString('xl/sharedStrings.xml', $sharedStrings);
    
    // xl/worksheets/sheet1.xml
    $worksheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <sheetData>
        <row r="1">
            <c r="A1" t="s"><v>0</v></c>
            <c r="B1" t="s"><v>1</v></c>
            <c r="C1" t="s"><v>2</v></c>
            <c r="D1" t="s"><v>3</v></c>
            <c r="E1" t="s"><v>4</v></c>
        </row>
        <row r="2">
            <c r="A2" t="s"><v>5</v></c>
            <c r="B2" t="s"><v>6</v></c>
            <c r="C2" t="s"><v>7</v></c>
            <c r="D2"><v>5551234567</v></c>
            <c r="E2"><v>México</v></c>
        </row>
    </sheetData>
</worksheet>';
    $zip->addFromString('xl/worksheets/sheet1.xml', $worksheet);
    
    $zip->close();
    
    echo "=== Archivo Excel de prueba creado ===\n";
    echo "Ruta: " . $tempFile . "\n";
    echo "Tamaño: " . filesize($tempFile) . " bytes\n";
    
    // Ahora vamos a probar nuestro procesador
    require_once 'import-simple.php';
    
    echo "\n=== Probando procesador Excel ===\n";
    $data = processExcel($tempFile);
    
    if (!empty($data)) {
        echo "✓ Datos extraídos exitosamente!\n";
        echo "Filas encontradas: " . count($data) . "\n";
        echo "Columnas: " . implode(', ', array_keys($data[0])) . "\n";
        echo "Primera fila: " . json_encode($data[0]) . "\n";
    } else {
        echo "✗ No se pudieron extraer datos\n";
    }
    
    // Limpiar
    unlink($tempFile);
    
} else {
    echo "Error al crear el archivo ZIP\n";
}

echo "\n=== Test completado ===\n";
?>