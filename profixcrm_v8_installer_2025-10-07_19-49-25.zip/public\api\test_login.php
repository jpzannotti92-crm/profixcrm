<?php
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../src/Database/Connection.php';

use iaTradeCRM\Database\Connection;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

echo "=== TEST DE LOGIN ===\n";

try {
    $db = Connection::getInstance()->getConnection();
    echo "✅ Conexión a BD exitosa\n";
    
    // Buscar usuario admin
    $stmt = $db->prepare("
        SELECT u.*, 
               d.name as desk_name,
               d.id as desk_id,
               supervisor.first_name as supervisor_first_name,
               supervisor.last_name as supervisor_last_name,
               GROUP_CONCAT(DISTINCT r.name) as roles,
               GROUP_CONCAT(DISTINCT r.display_name) as role_names,
               GROUP_CONCAT(DISTINCT p.name) as permissions
        FROM users u
        LEFT JOIN desk_users du ON u.id = du.user_id AND du.is_primary = 1
        LEFT JOIN desks d ON du.desk_id = d.id
        LEFT JOIN users supervisor ON d.manager_id = supervisor.id
        LEFT JOIN user_roles ur ON u.id = ur.user_id
        LEFT JOIN roles r ON ur.role_id = r.id
        LEFT JOIN role_permissions rp ON r.id = rp.role_id
        LEFT JOIN permissions p ON rp.permission_id = p.id
        WHERE (u.username = ? OR u.email = ?) AND u.status = 'active'
        GROUP BY u.id
    ");
    
    $stmt->execute(['admin', 'admin']);
    $user = $stmt->fetch();
    
    if ($user) {
        echo "✅ Usuario encontrado: " . $user['username'] . "\n";
        echo "📧 Email: " . $user['email'] . "\n";
        echo "👤 Nombre: " . $user['first_name'] . " " . $user['last_name'] . "\n";
        echo "🏢 Mesa: " . ($user['desk_name'] ?? 'Sin asignar') . "\n";
        echo "👔 Roles: " . ($user['roles'] ?? 'Sin roles') . "\n";
        echo "🔑 Permisos: " . ($user['permissions'] ?? 'Sin permisos') . "\n";
        
        // Verificar contraseña
        if (password_verify('admin123', $user['password_hash'])) {
            echo "✅ Contraseña correcta\n";
            
            // Generar JWT
            $secret = 'your-super-secret-jwt-key-change-in-production-2024';
            $payload = [
                'iss' => 'iatrade-crm',
                'aud' => 'iatrade-crm-users',
                'iat' => time(),
                'exp' => time() + (24 * 60 * 60),
                'user_id' => (int)$user['id'],
                'username' => $user['username'],
                'email' => $user['email'],
                'roles' => $user['roles'] ? explode(',', $user['roles']) : [],
                'permissions' => $user['permissions'] ? array_unique(explode(',', $user['permissions'])) : [],
                'desk_id' => $user['desk_id'] ? (int)$user['desk_id'] : null
            ];
            
            $jwt = JWT::encode($payload, $secret, 'HS256');
            echo "✅ JWT generado exitosamente\n";
            echo "Token: " . substr($jwt, 0, 50) . "...\n";
            
            echo json_encode([
                'success' => true,
                'message' => 'Login exitoso',
                'token' => $jwt,
                'user' => [
                    'id' => (int)$user['id'],
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'first_name' => $user['first_name'],
                    'last_name' => $user['last_name'],
                    'roles' => $user['roles'] ? explode(',', $user['roles']) : [],
                    'permissions' => $user['permissions'] ? array_unique(explode(',', $user['permissions'])) : []
                ]
            ]);
            
        } else {
            echo "❌ Contraseña incorrecta\n";
        }
    } else {
        echo "❌ Usuario no encontrado\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}
?>
