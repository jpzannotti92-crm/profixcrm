<?php
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../src/Database/Connection.php';

use iaTradeCRM\Database\Connection;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

header('Content-Type: text/plain');
header('Access-Control-Allow-Origin: *');

echo "=== TEST COMPLETO DE AUTENTICACIÓN ===\n\n";

try {
    // 1. Test de conexión a BD
    echo "1. PROBANDO CONEXIÓN A BASE DE DATOS...\n";
    $db = Connection::getInstance()->getConnection();
    echo "✅ Conexión exitosa\n\n";
    
    // 2. Verificar usuario admin
    echo "2. VERIFICANDO USUARIO ADMIN...\n";
    $stmt = $db->prepare("SELECT * FROM users WHERE username = 'admin'");
    $stmt->execute();
    $user = $stmt->fetch();
    
    if ($user) {
        echo "✅ Usuario admin encontrado\n";
        echo "   ID: " . $user['id'] . "\n";
        echo "   Username: " . $user['username'] . "\n";
        echo "   Email: " . $user['email'] . "\n";
        echo "   Status: " . $user['status'] . "\n";
        
        // Verificar contraseña
        if (password_verify('admin123', $user['password_hash'])) {
            echo "✅ Contraseña correcta\n\n";
        } else {
            echo "❌ Contraseña incorrecta\n\n";
        }
    } else {
        echo "❌ Usuario admin no encontrado\n\n";
    }
    
    // 3. Test de consulta completa con JOINs
    echo "3. PROBANDO CONSULTA COMPLETA CON JOINS...\n";
    $stmt = $db->prepare("
        SELECT u.*, 
               d.name as desk_name,
               d.id as desk_id,
               supervisor.first_name as supervisor_first_name,
               supervisor.last_name as supervisor_last_name,
               GROUP_CONCAT(DISTINCT r.name) as roles,
               GROUP_CONCAT(DISTINCT r.display_name) as role_names,
               GROUP_CONCAT(DISTINCT p.name) as permissions
        FROM users u
        LEFT JOIN desk_users du ON u.id = du.user_id AND du.is_primary = 1
        LEFT JOIN desks d ON du.desk_id = d.id
        LEFT JOIN users supervisor ON d.manager_id = supervisor.id
        LEFT JOIN user_roles ur ON u.id = ur.user_id
        LEFT JOIN roles r ON ur.role_id = r.id
        LEFT JOIN role_permissions rp ON r.id = rp.role_id
        LEFT JOIN permissions p ON rp.permission_id = p.id
        WHERE u.username = 'admin' AND u.status = 'active'
        GROUP BY u.id
    ");
    $stmt->execute();
    $userComplete = $stmt->fetch();
    
    if ($userComplete) {
        echo "✅ Consulta completa exitosa\n";
        echo "   Roles: " . ($userComplete['roles'] ?? 'Sin roles') . "\n";
        echo "   Permisos: " . (substr($userComplete['permissions'] ?? 'Sin permisos', 0, 100)) . "...\n";
        echo "   Mesa: " . ($userComplete['desk_name'] ?? 'Sin mesa') . "\n\n";
    } else {
        echo "❌ Error en consulta completa\n\n";
    }
    
    // 4. Test de generación JWT
    echo "4. PROBANDO GENERACIÓN DE JWT...\n";
    try {
        $secret = 'your-super-secret-jwt-key-change-in-production-2024';
        $payload = [
            'iss' => 'iatrade-crm',
            'aud' => 'iatrade-crm-users',
            'iat' => time(),
            'exp' => time() + (24 * 60 * 60),
            'user_id' => 1,
            'username' => 'admin',
            'email' => 'admin@iatrade.com'
        ];
        
        $jwt = JWT::encode($payload, $secret, 'HS256');
        echo "✅ JWT generado exitosamente\n";
        echo "   Token: " . substr($jwt, 0, 50) . "...\n\n";
        
        // 5. Test de verificación JWT
        echo "5. PROBANDO VERIFICACIÓN DE JWT...\n";
        $decoded = JWT::decode($jwt, new Key($secret, 'HS256'));
        echo "✅ JWT verificado exitosamente\n";
        echo "   User ID: " . $decoded->user_id . "\n";
        echo "   Username: " . $decoded->username . "\n";
        echo "   Expira: " . date('Y-m-d H:i:s', $decoded->exp) . "\n\n";
        
    } catch (Exception $e) {
        echo "❌ Error con JWT: " . $e->getMessage() . "\n\n";
    }
    
    // 6. Simular login completo
    echo "6. SIMULANDO LOGIN COMPLETO...\n";
    $loginData = [
        'username' => 'admin',
        'password' => 'admin123',
        'remember' => false
    ];
    
    // Verificar usuario
    if ($userComplete && password_verify($loginData['password'], $userComplete['password_hash'])) {
        // Generar respuesta de login
        $userData = [
            'id' => (int)$userComplete['id'],
            'username' => $userComplete['username'],
            'email' => $userComplete['email'],
            'first_name' => $userComplete['first_name'],
            'last_name' => $userComplete['last_name'],
            'roles' => $userComplete['roles'] ? explode(',', $userComplete['roles']) : [],
            'permissions' => $userComplete['permissions'] ? array_unique(explode(',', $userComplete['permissions'])) : []
        ];
        
        echo "✅ Login simulado exitoso\n";
        echo "   Datos del usuario: " . json_encode($userData, JSON_PRETTY_PRINT) . "\n\n";
    } else {
        echo "❌ Error en login simulado\n\n";
    }
    
    echo "=== RESUMEN ===\n";
    echo "✅ Conexión a BD: OK\n";
    echo "✅ Usuario admin: OK\n";
    echo "✅ Consulta completa: OK\n";
    echo "✅ JWT: OK\n";
    echo "✅ Login simulado: OK\n\n";
    echo "🎉 TODOS LOS TESTS PASARON - EL SISTEMA DE AUTH ESTÁ FUNCIONANDO\n";
    
} catch (Exception $e) {
    echo "❌ ERROR GENERAL: " . $e->getMessage() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}
?>
