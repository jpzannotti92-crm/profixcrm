<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Cargar autoloader de Composer
require_once __DIR__ . '/../../vendor/autoload.php';

// Cargar variables de entorno
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../../');
$dotenv->load();

// Cargar archivos necesarios
require_once __DIR__ . '/../../src/Database/Connection.php';
require_once __DIR__ . '/../../src/Models/BaseModel.php';
require_once __DIR__ . '/../../src/Models/User.php';
require_once __DIR__ . '/../../src/Middleware/RBACMiddleware.php';
require_once __DIR__ . '/../../src/Core/Request.php';

use iaTradeCRM\Database\Connection;
use IaTradeCRM\Models\User;
use IaTradeCRM\Middleware\RBACMiddleware;
use IaTradeCRM\Core\Request;

try {
    $db = Connection::getInstance();
    
    // Inicializar middleware RBAC
    $rbacMiddleware = new RBACMiddleware();
    $request = new Request();
    
    // Log de depuración
    error_log("=== TEST BULK ASSIGN ===");
    error_log("Método: " . $_SERVER['REQUEST_METHOD']);
    error_log("Headers: " . json_encode(getallheaders()));
    
    // Autenticar usuario
    $authResult = $rbacMiddleware->handle($request);
    if ($authResult !== true) {
        error_log("Error de autenticación: " . json_encode($authResult));
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'message' => 'Error de autenticación',
            'debug' => 'Usuario no autenticado'
        ]);
        exit();
    }
    
    $currentUser = $request->user;
    error_log("Usuario autenticado: " . $currentUser->id . " - " . $currentUser->username);
    
    // Verificar permisos para asignar leads
    $hasAssignPermission = $currentUser->hasPermission('leads.assign');
    $hasEditPermission = $currentUser->hasPermission('leads.edit');
    
    error_log("Permisos - assign: " . ($hasAssignPermission ? 'SI' : 'NO') . ", edit: " . ($hasEditPermission ? 'SI' : 'NO'));
    
    if (!$hasAssignPermission && !$hasEditPermission) {
        error_log("Usuario sin permisos suficientes");
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'No tienes permisos para asignar leads',
            'debug' => 'Permisos insuficientes'
        ]);
        exit();
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Leer datos de entrada
        $inputRaw = file_get_contents('php://input');
        error_log("Datos raw recibidos: " . $inputRaw);
        
        $input = json_decode($inputRaw, true);
        error_log("Datos decodificados: " . json_encode($input));
        
        if (!$input) {
            error_log("Error: Datos inválidos o JSON malformado");
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Datos inválidos',
                'debug' => 'JSON malformado'
            ]);
            exit();
        }
        
        // Validar datos requeridos
        if (!isset($input['leadIds']) || !is_array($input['leadIds']) || empty($input['leadIds'])) {
            error_log("Error: leadIds faltante o inválido");
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Se requiere una lista de IDs de leads',
                'debug' => 'leadIds inválido'
            ]);
            exit();
        }
        
        if (!isset($input['assignments']) || !is_array($input['assignments']) || empty($input['assignments'])) {
            error_log("Error: assignments faltante o inválido");
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Se requieren las asignaciones de usuarios',
                'debug' => 'assignments inválido'
            ]);
            exit();
        }
        
        $leadIds = $input['leadIds'];
        $assignments = $input['assignments'];
        
        error_log("leadIds: " . json_encode($leadIds));
        error_log("assignments: " . json_encode($assignments));
        
        // Respuesta de prueba exitosa
        echo json_encode([
            'success' => true,
            'message' => 'Prueba exitosa - datos recibidos correctamente',
            'data' => [
                'assigned_count' => count($leadIds),
                'error_count' => 0,
                'total_processed' => count($leadIds),
                'leadIds' => $leadIds,
                'assignments' => $assignments,
                'user' => [
                    'id' => $currentUser->id,
                    'username' => $currentUser->username
                ]
            ]
        ]);
        
    } else {
        http_response_code(405);
        echo json_encode([
            'success' => false,
            'message' => 'Método no permitido'
        ]);
    }
    
} catch (Exception $e) {
    error_log("Error en test_bulk_assign: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error interno del servidor',
        'debug' => $e->getMessage()
    ]);
}
?>