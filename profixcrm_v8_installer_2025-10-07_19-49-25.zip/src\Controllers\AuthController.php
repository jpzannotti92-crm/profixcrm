<?php

namespace IaTradeCRM\Controllers;

use IaTradeCRM\Core\Request;
use IaTradeCRM\Core\Response;
use IaTradeCRM\Models\User;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class AuthController extends BaseController
{
    private $jwtSecret;
    private $jwtExpiration;

    public function __construct()
    {
        parent::__construct();
        $this->jwtSecret = $_ENV['JWT_SECRET'] ?? 'password';
        $this->jwtExpiration = 3600 * 24 * 7; // 7 días
    }

    /**
     * Mostrar página de login
     */
    public function showLogin()
    {
        // Si ya está autenticado, redirigir al dashboard
        if ($this->isAuthenticated()) {
// REDIRECCIÓN TEMPORALMENTE DESACTIVADA - // REDIRECCIÓN TEMPORALMENTE DESACTIVADA -             header('Location: /premium.html');
            exit;
        }

        // Redirigir siempre a la ruta de SPA
// REDIRECCIÓN TEMPORALMENTE DESACTIVADA - // REDIRECCIÓN TEMPORALMENTE DESACTIVADA -         header('Location: /auth/login');
        exit;
    }

    /**
     * Procesar login
     */
    public function login(Request $request)
    {
        try {
            $data = $request->getJsonData();
            
            // Validar datos requeridos
            if (empty($data['username']) || empty($data['password'])) {
                return Response::json([
                    'success' => false,
                    'message' => 'Usuario y contraseña son requeridos'
                ], 400);
            }

            $username = trim($data['username']);
            $password = $data['password'];
            $remember = $data['remember'] ?? false;

            // Buscar usuario por username o email
            $user = User::findByUsernameOrEmail($username);

            if (!$user) {
                // Log intento de login fallido
                $this->logFailedAttempt($username, $request->getClientIp());
                
                return Response::json([
                    'success' => false,
                    'message' => 'Credenciales incorrectas'
                ], 401);
            }

            // Verificar si la cuenta está bloqueada
            if ($this->isAccountLocked($user)) {
                return Response::json([
                    'success' => false,
                    'message' => 'Cuenta temporalmente bloqueada por múltiples intentos fallidos'
                ], 423);
            }

            // Verificar contraseña
            if (!password_verify($password, $user->password_hash)) {
                // Incrementar intentos fallidos
                $this->incrementFailedAttempts($user);
                $this->logFailedAttempt($username, $request->getClientIp());
                
                return Response::json([
                    'success' => false,
                    'message' => 'Credenciales incorrectas'
                ], 401);
            }

            // Verificar estado de la cuenta
            if ($user->status !== 'active') {
                return Response::json([
                    'success' => false,
                    'message' => 'Cuenta inactiva. Contacta al administrador.'
                ], 403);
            }

            // Login exitoso - limpiar intentos fallidos
            $this->clearFailedAttempts($user);

            // Generar JWT token
            $tokenExpiration = $remember ? (time() + $this->jwtExpiration) : (time() + 3600); // 1 hora si no recuerda
            $token = $this->generateJWT($user, $tokenExpiration);

            // Actualizar último login
            $this->updateLastLogin($user);

            // Obtener roles y permisos del usuario
            $userRoles = $user->getRoles();
            $userPermissions = $user->getPermissions();

            // Log login exitoso
            $this->logSuccessfulLogin($user, $request->getClientIp());

            return Response::json([
                'success' => true,
                'message' => 'Login exitoso',
                'token' => $token,
                'user' => [
                    'id' => $user->id,
                    'username' => $user->username,
                    'email' => $user->email,
                    'first_name' => $user->first_name,
                    'last_name' => $user->last_name,
                    'avatar' => $user->avatar,
                    'roles' => $userRoles,
                    'permissions' => $userPermissions
                ],
                'redirect' => '/premium.html'
            ]);

        } catch (\Exception $e) {
            error_log('Login error: ' . $e->getMessage());
            
            return Response::json([
                'success' => false,
                'message' => 'Error interno del servidor'
            ], 500);
        }
    }

    /**
     * Verificar token JWT
     */
    public function verify(Request $request)
    {
        try {
            $token = $this->extractTokenFromRequest($request);
            
            if (!$token) {
                return Response::json([
                    'valid' => false,
                    'message' => 'Token no proporcionado'
                ], 401);
            }

            $decoded = JWT::decode($token, new Key($this->jwtSecret, 'HS256'));
            
            // Verificar que el usuario aún existe y está activo
            $user = User::find($decoded->user_id);
            
            if (!$user || $user->status !== 'active') {
                return Response::json([
                    'valid' => false,
                    'message' => 'Usuario no válido'
                ], 401);
            }

            return Response::json([
                'valid' => true,
                'user' => [
                    'id' => $user->id,
                    'username' => $user->username,
                    'email' => $user->email,
                    'first_name' => $user->first_name,
                    'last_name' => $user->last_name,
                    'roles' => $user->getRoles(),
                    'permissions' => $user->getPermissions()
                ]
            ]);

        } catch (\Exception $e) {
            return Response::json([
                'valid' => false,
                'message' => 'Token inválido'
            ], 401);
        }
    }

    /**
     * Logout
     */
    public function logout(Request $request)
    {
        try {
            $token = $this->extractTokenFromRequest($request);
            
            if ($token) {
                // Aquí podrías agregar el token a una blacklist si lo deseas
                $this->addTokenToBlacklist($token);
            }

            return Response::json([
                'success' => true,
                'message' => 'Logout exitoso'
            ]);

        } catch (\Exception $e) {
            return Response::json([
                'success' => false,
                'message' => 'Error al cerrar sesión'
            ], 500);
        }
    }

    /**
     * Obtener usuario actual
     */
    public function me(Request $request)
    {
        try {
            $user = $this->getCurrentUser($request);
            
            if (!$user) {
                return Response::json([
                    'success' => false,
                    'message' => 'Usuario no autenticado'
                ], 401);
            }

            return Response::json([
                'success' => true,
                'user' => [
                    'id' => $user->id,
                    'username' => $user->username,
                    'email' => $user->email,
                    'first_name' => $user->first_name,
                    'last_name' => $user->last_name,
                    'avatar' => $user->avatar,
                    'roles' => $user->getRoles(),
                    'permissions' => $user->getPermissions(),
                    'last_login' => $user->last_login
                ]
            ]);

        } catch (\Exception $e) {
            return Response::json([
                'success' => false,
                'message' => 'Error al obtener datos del usuario'
            ], 500);
        }
    }

    /**
     * Generar JWT token
     */
    private function generateJWT($user, $expiration)
    {
        $payload = [
            'iss' => $_SERVER['HTTP_HOST'] ?? 'iatrade-crm',
            'aud' => $_SERVER['HTTP_HOST'] ?? 'iatrade-crm',
            'iat' => time(),
            'exp' => $expiration,
            'user_id' => $user->id,
            'username' => $user->username,
            'email' => $user->email
        ];

        return JWT::encode($payload, $this->jwtSecret, 'HS256');
    }

    /**
     * Extraer token del request
     */
    private function extractTokenFromRequest(Request $request)
    {
        $authHeader = $request->getHeader('Authorization');
        
        if ($authHeader && preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            return $matches[1];
        }

        return null;
    }

    /**
     * Obtener usuario actual desde token
     */
    private function getCurrentUser(Request $request)
    {
        try {
            $token = $this->extractTokenFromRequest($request);
            
            if (!$token) {
                return null;
            }

            $decoded = JWT::decode($token, new Key($this->jwtSecret, 'HS256'));
            
            return User::find($decoded->user_id);

        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Verificar si está autenticado
     */
    private function isAuthenticated()
    {
        $request = new Request();
        return $this->getCurrentUser($request) !== null;
    }

    /**
     * Verificar si la cuenta está bloqueada
     */
    private function isAccountLocked($user)
    {
        if (!$user->locked_until) {
            return false;
        }

        return strtotime($user->locked_until) > time();
    }

    /**
     * Incrementar intentos fallidos
     */
    private function incrementFailedAttempts($user)
    {
        $attempts = $user->login_attempts + 1;
        $lockedUntil = null;

        // Bloquear después de 5 intentos fallidos por 15 minutos
        if ($attempts >= 5) {
            $lockedUntil = date('Y-m-d H:i:s', time() + (15 * 60));
        }

        User::update($user->id, [
            'login_attempts' => $attempts,
            'locked_until' => $lockedUntil
        ]);
    }

    /**
     * Limpiar intentos fallidos
     */
    private function clearFailedAttempts($user)
    {
        User::update($user->id, [
            'login_attempts' => 0,
            'locked_until' => null
        ]);
    }

    /**
     * Actualizar último login
     */
    private function updateLastLogin($user)
    {
        User::update($user->id, [
            'last_login' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Log intento fallido
     */
    private function logFailedAttempt($username, $ip)
    {
        error_log("Failed login attempt - Username: {$username}, IP: {$ip}");
        
        // Aquí podrías guardar en base de datos para análisis de seguridad
    }

    /**
     * Log login exitoso
     */
    private function logSuccessfulLogin($user, $ip)
    {
        error_log("Successful login - User: {$user->username}, IP: {$ip}");
        
        // Aquí podrías guardar en audit_logs
    }

    /**
     * Agregar token a blacklist (opcional)
     */
    private function addTokenToBlacklist($token)
    {
        // Implementar si necesitas invalidar tokens específicos
        // Por ejemplo, guardar en Redis o base de datos
    }
}