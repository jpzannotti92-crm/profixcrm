<?php
// Test para verificar errores en import.php
require_once '../../config/database.php';

// Probar las funciones que faltan
try {
    // Simular datos de prueba
    $testRow = [
        'first_name' => 'Juan',
        'last_name' => 'Pérez',
        'email' => 'juan@test.com',
        'phone' => '1234567890',
        'country' => 'México'
    ];
    
    $testMapping = [
        'first_name' => 'first_name',
        'last_name' => 'last_name',
        'email' => 'email',
        'phone' => 'phone',
        'country' => 'country'
    ];
    
    // Probar mapRowToLead
    if (function_exists('mapRowToLead')) {
        echo "✓ mapRowToLead existe\n";
        $result = mapRowToLead($testRow, $testMapping);
        echo "Resultado: " . json_encode($result, JSON_PRETTY_PRINT) . "\n";
    } else {
        echo "✗ mapRowToLead NO existe\n";
    }
    
    // Probar processCSV
    if (function_exists('processCSV')) {
        echo "✓ processCSV existe\n";
    } else {
        echo "✗ processCSV NO existe\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

// Incluir el archivo para verificar errores
include_once 'import.php';

// Verificar si las funciones ahora existen
echo "\nDespués de incluir import.php:\n";
echo "mapRowToLead existe: " . (function_exists('mapRowToLead') ? 'Sí' : 'No') . "\n";
echo "processCSV existe: " . (function_exists('processCSV') ? 'Sí' : 'No') . "\n";
?>