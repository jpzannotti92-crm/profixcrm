<?php
// Test para verificar el endpoint de importación
require_once '../../config/database.php';
require_once 'database.php';

echo "=== Test de Importación de Leads ===\n\n";

// Verificar que las funciones existan
echo "1. Verificando funciones:\n";
echo "   - errorResponse existe: " . (function_exists('errorResponse') ? 'Sí' : 'No') . "\n";
echo "   - successResponse existe: " . (function_exists('successResponse') ? 'Sí' : 'No') . "\n";
echo "   - processCSV existe: " . (function_exists('processCSV') ? 'Sí' : 'No') . "\n";
echo "   - mapRowToLead existe: " . (function_exists('mapRowToLead') ? 'Sí' : 'No') . "\n\n";

// Probar las funciones con datos de prueba
echo "2. Probando funciones:\n";

// Test processCSV
$testData = processCSV('test_leads.csv');
echo "   - processCSV: " . count($testData) . " filas procesadas\n";

// Test mapRowToLead
$mapping = [
    'first_name' => 'first_name',
    'last_name' => 'last_name',
    'email' => 'email',
    'phone' => 'phone',
    'country' => 'country',
    'campaign' => 'campaign',
    'source' => 'source'
];

if (!empty($testData)) {
    $mappedLead = mapRowToLead($testData[0], $mapping);
    echo "   - mapRowToLead: " . json_encode($mappedLead, JSON_PRETTY_PRINT) . "\n";
}

echo "\n3. Verificando conexión a base de datos:\n";
try {
    $config = require '../../config/database.php';
    $dbConfig = $config['connections']['mysql'];
    
    $dsn = "mysql:host={$dbConfig['host']};port={$dbConfig['port']};dbname={$dbConfig['database']};charset={$dbConfig['charset']}";
    $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], $dbConfig['options']);
    
    echo "   - Conexión exitosa\n";
    
    // Verificar tabla leads
    $stmt = $pdo->query("SELECT COUNT(*) FROM leads");
    $count = $stmt->fetchColumn();
    echo "   - Total leads actual: $count\n";
    
} catch (Exception $e) {
    echo "   - Error de conexión: " . $e->getMessage() . "\n";
}

echo "\n=== Test completado ===\n";
?>