<?php
require_once __DIR__ . '/../public/api/desks.php';