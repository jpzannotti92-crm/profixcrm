<?php
header('Content-Type: text/plain');

echo "=== TEST CREAR USUARIO SIMPLE ===\n\n";

$url = 'http://localhost:8000/api/api/users.php';
$data = json_encode([
    'username' => 'test_simple',
    'email' => 'test_simple@test.com',
    'password' => 'password123',
    'first_name' => 'Test',
    'last_name' => 'Simple',
    'status' => 'active'
]);

echo "URL: $url\n";
echo "Data: $data\n\n";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "HTTP Code: $httpCode\n";
echo "Response: $response\n";

if ($error) {
    echo "cURL Error: $error\n";
}
?>