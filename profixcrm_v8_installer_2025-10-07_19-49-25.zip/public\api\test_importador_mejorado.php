<?php
/**
 * Test del importador mejorado con el CSV de 500 leads
 */

// Crear archivo CSV temporal con los datos del archivo grande
$csvContent = file_get_contents(__DIR__ . '/../../500_leads.csv');
$tempFile = tempnam(sys_get_temp_dir(), 'leads_') . '.csv';
file_put_contents($tempFile, $csvContent);

echo "=== Archivo CSV temporal creado ===\n";
echo "Ruta: $tempFile\n";
echo "Tamaño: " . filesize($tempFile) . " bytes\n\n";

// Preparar datos POST para simular el envío del formulario
$postData = [
    'mapping' => json_encode([
        'first_name' => 'first_name',
        'last_name' => 'last_name',
        'email' => 'email',
        'phone' => 'phone',
        'country' => 'country',
        'city' => 'city',
        'company' => 'company',
        'job_title' => 'job_title'
    ])
];

// Crear el array $_FILES simulado
$_FILES = [
    'file' => [
        'name' => '500_leads.csv',
        'type' => 'text/csv',
        'tmp_name' => $tempFile,
        'error' => UPLOAD_ERR_OK,
        'size' => filesize($tempFile)
    ]
];

// Crear el array $_POST simulado
$_POST = $postData;

// Establecer el método POST
$_SERVER['REQUEST_METHOD'] = 'POST';

echo "=== Ejecutando importador mejorado ===\n";

// Incluir el importador mejorado
ob_start();
require_once 'importador_mejorado.php';
$output = ob_get_clean();

// Mostrar resultado
$result = json_decode($output, true);
if (json_last_error() === JSON_ERROR_NONE) {
    echo "Resultado de importación:\n";
    echo "- Total de filas: " . $result['data']['total_rows'] . "\n";
    echo "- Filas importadas: " . $result['data']['imported_rows'] . "\n";
    echo "- Filas duplicadas: " . $result['data']['duplicate_rows'] . "\n";
    echo "- Filas con error: " . $result['data']['failed_rows'] . "\n";
    
    if (!empty($result['data']['errors'])) {
        echo "\n=== Primeros errores ===\n";
        foreach ($result['data']['errors'] as $error) {
            echo "Fila {$error['row']}: " . implode(', ', $error['errors']) . "\n";
            echo "  Datos: " . json_encode($error['data'], JSON_UNESCAPED_UNICODE) . "\n\n";
        }
    }
} else {
    echo "Error al decodificar JSON: " . json_last_error_msg() . "\n";
    echo "Salida cruda: $output\n";
}

// Limpiar archivo temporal
unlink($tempFile);
echo "\n=== Archivo temporal eliminado ===\n";

// Verificar cuántos leads hay ahora
try {
    require_once __DIR__ . '/../../src/Database/Connection.php';
    
    use iaTradeCRM\Database\Connection;
    
    $connection = Connection::getInstance();
    $pdo = $connection->getConnection();
    
    $stmt = $pdo->query('SELECT COUNT(*) as total FROM leads');
    $total = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "\n=== Total de leads en la base de datos: " . $total['total'] . " ===\n";
    
} catch (Exception $e) {
    echo "Error al contar leads: " . $e->getMessage() . "\n";
}