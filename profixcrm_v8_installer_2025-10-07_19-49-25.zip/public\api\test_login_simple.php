<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

echo "=== TEST LOGIN SIMPLE ===\n\n";

// Test directo del endpoint
$url = 'http://localhost:8000/api/api/auth/login.php';
$data = json_encode([
    'username' => 'admin',
    'password' => 'admin123',
    'remember' => false
]);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "URL: $url\n";
echo "Data enviada: $data\n";
echo "HTTP Code: $httpCode\n";

if ($error) {
    echo "❌ Error cURL: $error\n";
} else {
    echo "✅ Respuesta recibida:\n";
    echo "$response\n\n";
    
    $decoded = json_decode($response, true);
    if ($decoded) {
        echo "📋 Análisis:\n";
        echo "- Success: " . ($decoded['success'] ? 'true' : 'false') . "\n";
        echo "- Message: " . ($decoded['message'] ?? 'no message') . "\n";
        echo "- Token: " . (isset($decoded['token']) ? 'SÍ (' . substr($decoded['token'], 0, 20) . '...)' : 'NO') . "\n";
        echo "- User: " . (isset($decoded['user']) ? 'SÍ (ID: ' . $decoded['user']['id'] . ')' : 'NO') . "\n";
        
        if ($decoded['success'] && isset($decoded['token']) && isset($decoded['user'])) {
            echo "\n🎉 LOGIN FUNCIONANDO CORRECTAMENTE\n";
        } else {
            echo "\n❌ LOGIN CON PROBLEMAS\n";
        }
    } else {
        echo "❌ Error decodificando JSON: " . json_last_error_msg() . "\n";
    }
}
?>