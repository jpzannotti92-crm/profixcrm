<?php
// Alias: enruta al endpoint público para resetear contraseña
require_once __DIR__ . '/../../public/api/auth/reset_admin.php';
?>