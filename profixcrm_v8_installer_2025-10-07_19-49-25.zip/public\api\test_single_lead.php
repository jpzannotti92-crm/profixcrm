<?php
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../src/Database/Connection.php';

use iaTradeCRM\Database\Connection;

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    $db = Connection::getInstance()->getConnection();
    
    // Datos de prueba para un solo lead
    $testLead = [
        'first_name' => 'Test',
        'last_name' => 'Single',
        'email' => 'test.single@example.com',
        'phone' => '+1234567890',
        'country' => 'España',
        'city' => 'Madrid',
        'company' => 'Test Company',
        'job_title' => 'Manager',
        'source' => 'Test',
        'status' => 'new',
        'priority' => 'medium'
    ];
    
    echo "Intentando insertar lead de prueba...\n";
    echo "Datos: " . json_encode($testLead) . "\n\n";
    
    // Insertar lead
    $stmt = $db->prepare("
        INSERT INTO leads (
            first_name, last_name, email, phone, country, city, 
            company, job_title, source, status, priority, 
            value, notes, assigned_to, desk_id, created_at, updated_at
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW()
        )
    ");
    
    $result = $stmt->execute([
        $testLead['first_name'],
        $testLead['last_name'],
        $testLead['email'],
        $testLead['phone'],
        $testLead['country'],
        $testLead['city'],
        $testLead['company'],
        $testLead['job_title'],
        $testLead['source'],
        $testLead['status'],
        $testLead['priority'],
        null, // value
        '', // notes
        null, // assigned_to
        null  // desk_id
    ]);
    
    if ($result) {
        $leadId = $db->lastInsertId();
        echo "✅ Lead insertado exitosamente con ID: $leadId\n";
        
        // Verificar que se insertó
        $checkStmt = $db->prepare("SELECT * FROM leads WHERE id = ?");
        $checkStmt->execute([$leadId]);
        $insertedLead = $checkStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($insertedLead) {
            echo "✅ Lead verificado en la base de datos\n";
            echo "Datos insertados: " . json_encode($insertedLead) . "\n";
        } else {
            echo "❌ Lead no encontrado después de la inserción\n";
        }
        
        // Contar total de leads
        $countStmt = $db->query("SELECT COUNT(*) as total FROM leads");
        $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
        echo "Total de leads en la base de datos: $total\n";
        
        echo json_encode([
            'success' => true,
            'message' => 'Lead de prueba insertado exitosamente',
            'lead_id' => $leadId,
            'total_leads' => $total,
            'inserted_data' => $insertedLead
        ]);
        
    } else {
        $errorInfo = $stmt->errorInfo();
        echo "❌ Error al insertar lead\n";
        echo "Error SQL: " . $errorInfo[2] . "\n";
        
        echo json_encode([
            'success' => false,
            'message' => 'Error al insertar lead de prueba',
            'sql_error' => $errorInfo[2]
        ]);
    }
    
} catch (Exception $e) {
    echo "❌ Excepción: " . $e->getMessage() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>