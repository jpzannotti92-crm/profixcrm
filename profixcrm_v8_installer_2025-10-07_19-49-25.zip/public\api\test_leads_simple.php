<?php
// Versión compatible con CLI PHP 8.0: evita Composer
require_once __DIR__ . '/database.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

try {
    $db = getDbConnection();
    
    // Verificar si la tabla leads existe
    $stmt = $db->query("SHOW TABLES LIKE 'leads'");
    $tableExists = $stmt->rowCount() > 0;
    
    if (!$tableExists) {
        echo json_encode([
            'success' => false,
            'message' => 'La tabla leads no existe en la base de datos'
        ]);
        exit();
    }
    
    // Obtener algunos leads de prueba
    $stmt = $db->query("SELECT COUNT(*) as count FROM leads");
    $count = $stmt->fetch()['count'];
    
    $stmt = $db->query("SELECT * FROM leads LIMIT 5");
    $leads = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'message' => 'Conexión exitosa',
        'total_leads' => $count,
        'sample_leads' => $leads
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>