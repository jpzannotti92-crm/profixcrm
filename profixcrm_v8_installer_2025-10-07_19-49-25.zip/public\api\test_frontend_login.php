<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Simular exactamente lo que hace el frontend
$url = 'http://localhost:8000/api/api/auth/login.php';
$data = json_encode([
    'username' => 'admin',
    'password' => 'admin123',
    'remember' => false
]);

$options = [
    'http' => [
        'header' => "Content-Type: application/json\r\n",
        'method' => 'POST',
        'content' => $data
    ]
];

echo "=== TEST FRONTEND LOGIN ===\n\n";
echo "URL: $url\n";
echo "Data enviada: $data\n\n";

$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);

if ($result === FALSE) {
    echo "❌ Error en la petición\n";
    echo "Headers de respuesta:\n";
    print_r($http_response_header);
} else {
    echo "✅ Respuesta recibida:\n";
    echo $result . "\n\n";
    
    $decoded = json_decode($result, true);
    if ($decoded) {
        echo "📋 Análisis de respuesta:\n";
        echo "- Success: " . ($decoded['success'] ? 'true' : 'false') . "\n";
        echo "- Message: " . ($decoded['message'] ?? 'no message') . "\n";
        echo "- Token presente: " . (isset($decoded['token']) ? 'SÍ' : 'NO') . "\n";
        echo "- User presente: " . (isset($decoded['user']) ? 'SÍ' : 'NO') . "\n";
        
        if (isset($decoded['user'])) {
            echo "- User ID: " . ($decoded['user']['id'] ?? 'no id') . "\n";
            echo "- Username: " . ($decoded['user']['username'] ?? 'no username') . "\n";
            echo "- First name: " . ($decoded['user']['first_name'] ?? 'no first_name') . "\n";
        }
        
        echo "\n🎯 RESULTADO: ";
        if ($decoded['success'] && isset($decoded['token']) && isset($decoded['user'])) {
            echo "LOGIN EXITOSO - El frontend debería funcionar\n";
        } else {
            echo "LOGIN FALLIDO - Revisar respuesta\n";
        }
    } else {
        echo "❌ Error decodificando JSON\n";
        echo "JSON Error: " . json_last_error_msg() . "\n";
    }
}
?>