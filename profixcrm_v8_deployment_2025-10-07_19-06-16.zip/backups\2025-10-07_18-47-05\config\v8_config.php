<?php
/**
 * V8 CONFIGURATION SYSTEM
 * 
 * Sistema de configuración mejorado para ProfixCRM V8
 * Resuelve problemas de redirección y configuración de V7
 * 
 * @version 8.0.0
 * @author ProfixCRM
 */

class V8Config {
    private static $instance = null;
    private $config = [];
    private $environment;
    private $redirectMode;
    private $initialized = false;
    
    // Modos de redirección
    const REDIRECT_INTELLIGENT = 'intelligent';
    const REDIRECT_DISABLED = 'disabled';
    const REDIRECT_FORCED = 'forced';
    const REDIRECT_DEVELOPMENT = 'development';
    
    // Entornos
    const ENV_DEVELOPMENT = 'development';
    const ENV_STAGING = 'staging';
    const ENV_PRODUCTION = 'production';
    const ENV_TESTING = 'testing';
    
    // Rutas de validación (sin redirección)
    const VALIDATION_PATHS = [
        'validate_v8.php',
        'validate_v8_web.php',
        'validate_v8_web_ajax.php',
        'validate_cli.php',
        'validate_after_deploy.php',
        'production_check.php',
        'production_check_cli.php',
        'disable_redirects.php',
        'restore_redirects.php',
        'deploy_v8.php'
    ];
    
    private function __construct() {
        $this->initialize();
    }
    
    /**
     * Obtener instancia singleton
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Inicializar configuración
     */
    private function initialize() {
        if ($this->initialized) {
            return;
        }
        
        // Detectar entorno automáticamente
        $this->detectEnvironment();
        
        // Cargar configuración base
        $this->loadBaseConfiguration();
        
        // Cargar configuración de entorno
        $this->loadEnvironmentConfiguration();
        
        // Cargar configuración de archivos .env
        $this->loadEnvConfiguration();
        
        // Validar configuración
        $this->validateConfiguration();
        
        // Establecer constantes para compatibilidad
        $this->setCompatibilityConstants();
        
        $this->initialized = true;
    }
    
    /**
     * Detectar entorno automáticamente
     */
    private function detectEnvironment() {
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $serverName = $_SERVER['SERVER_NAME'] ?? 'localhost';
        $serverAddr = $_SERVER['SERVER_ADDR'] ?? '127.0.0.1';
        $documentRoot = $_SERVER['DOCUMENT_ROOT'] ?? '';
        
        // Detectar por host
        if (strpos($host, 'localhost') !== false || strpos($host, '127.0.0.1') !== false) {
            $this->environment = self::ENV_DEVELOPMENT;
        } elseif (strpos($host, 'staging') !== false || strpos($host, 'test') !== false) {
            $this->environment = self::ENV_STAGING;
        } elseif (strpos($host, 'spin2pay.com') !== false || strpos($host, 'profixcrm.com') !== false) {
            $this->environment = self::ENV_PRODUCTION;
        } else {
            // Detectar por IP o rutas
            if ($serverAddr === '127.0.0.1' || $serverAddr === '::1') {
                $this->environment = self::ENV_DEVELOPMENT;
            } elseif (strpos($documentRoot, 'xampp') !== false || strpos($documentRoot, 'wamp') !== false) {
                $this->environment = self::ENV_DEVELOPMENT;
            } else {
                $this->environment = self::ENV_STAGING;
            }
        }
        
        // Permitir override por variable de entorno
        if (getenv('V8_ENVIRONMENT')) {
            $this->environment = getenv('V8_ENVIRONMENT');
        }
        
        // Detectar modo de redirección basado en entorno
        $this->detectRedirectMode();
    }
    
    /**
     * Detectar modo de redirección
     */
    private function detectRedirectMode() {
        switch ($this->environment) {
            case self::ENV_DEVELOPMENT:
                $this->redirectMode = self::REDIRECT_DEVELOPMENT;
                break;
            case self::ENV_TESTING:
                $this->redirectMode = self::REDIRECT_DISABLED;
                break;
            case self::ENV_STAGING:
                $this->redirectMode = self::REDIRECT_INTELLIGENT;
                break;
            case self::ENV_PRODUCTION:
                $this->redirectMode = self::REDIRECT_INTELLIGENT;
                break;
            default:
                $this->redirectMode = self::REDIRECT_INTELLIGENT;
        }
        
        // Permitir override por variable de entorno
        if (getenv('V8_REDIRECT_MODE')) {
            $this->redirectMode = getenv('V8_REDIRECT_MODE');
        }
    }
    
    /**
     * Cargar configuración base
     */
    private function loadBaseConfiguration() {
        $this->config = [
            'app' => [
                'name' => 'ProfixCRM V8',
                'version' => '8.0.0',
                'environment' => $this->environment,
                'debug' => $this->environment === self::ENV_DEVELOPMENT,
                'timezone' => 'America/Mexico_City',
                'locale' => 'es_MX',
                'url' => $this->detectBaseUrl()
            ],
            'security' => [
                'encryption_key' => $this->generateEncryptionKey(),
                'jwt_secret' => $this->generateJwtSecret(),
                'session_lifetime' => 7200,
                'password_algorithm' => PASSWORD_BCRYPT,
                'csrf_protection' => true
            ],
            'redirect' => [
                'mode' => $this->redirectMode,
                'login_url' => '/auth/login',
                'dashboard_url' => '/dashboard',
                'allowed_paths' => self::VALIDATION_PATHS,
                'bypass_validation' => false,
                'development_bypass' => true
            ],
            'database' => [
                'default_connection' => 'mysql',
                'connections' => [
                    'mysql' => [
                        'driver' => 'mysql',
                        'host' => 'localhost',
                        'port' => '3306',
                        'database' => 'profixcrm',
                        'username' => 'root',
                        'password' => '',
                        'charset' => 'utf8mb4',
                        'collation' => 'utf8mb4_unicode_ci',
                        'prefix' => '',
                        'strict' => true,
                        'engine' => null
                    ]
                ]
            ],
            'logging' => [
                'enabled' => true,
                'level' => $this->getLogLevel(),
                'channels' => ['file', 'database'],
                'file' => [
                    'path' => __DIR__ . '/../logs/v8/',
                    'max_files' => 30,
                    'max_size' => '10MB'
                ]
            ],
            'cache' => [
                'enabled' => true,
                'driver' => 'file',
                'path' => __DIR__ . '/../cache/v8/',
                'prefix' => 'v8_',
                'ttl' => 3600
            ],
            'validation' => [
                'strict_mode' => true,
                'stop_on_first_failure' => false,
                'include_data_in_errors' => $this->environment === self::ENV_DEVELOPMENT
            ],
            'api' => [
                'enabled' => true,
                'rate_limit' => 1000,
                'rate_limit_window' => 3600,
                'cors_enabled' => true,
                'cors_origins' => ['*']
            ]
        ];
    }
    
    /**
     * Cargar configuración de entorno
     */
    private function loadEnvironmentConfiguration() {
        $envConfigFile = __DIR__ . '/v8_' . $this->environment . '.php';
        
        if (file_exists($envConfigFile)) {
            $envConfig = require $envConfigFile;
            $this->config = $this->mergeConfig($this->config, $envConfig);
        }
    }
    
    /**
     * Cargar configuración de archivos .env
     */
    private function loadEnvConfiguration() {
        $envFiles = [
            __DIR__ . '/../.env.v8',
            __DIR__ . '/../.env.' . $this->environment,
            __DIR__ . '/../.env'
        ];
        
        foreach ($envFiles as $envFile) {
            if (file_exists($envFile)) {
                $this->parseEnvFile($envFile);
            }
        }
        
        // Cargar variables de entorno del sistema
        $this->loadSystemEnvVars();
    }
    
    /**
     * Parsear archivo .env
     */
    private function parseEnvFile($file) {
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        foreach ($lines as $line) {
            if (strpos($line, '#') === 0) {
                continue; // Saltar comentarios
            }
            
            if (strpos($line, '=') !== false) {
                list($key, $value) = explode('=', $line, 2);
                $key = trim($key);
                $value = trim($value, " \t\n\r\0\x0B\"'");
                
                $this->setEnvValue($key, $value);
            }
        }
    }
    
    /**
     * Establecer valor de entorno
     */
    private function setEnvValue($key, $value) {
        // Mapear claves de entorno a configuración
        $mappings = [
            'APP_URL' => 'app.url',
            'APP_DEBUG' => 'app.debug',
            'DB_HOST' => 'database.connections.mysql.host',
            'DB_NAME' => 'database.connections.mysql.database',
            'DB_USER' => 'database.connections.mysql.username',
            'DB_PASS' => 'database.connections.mysql.password',
            'DB_PORT' => 'database.connections.mysql.port',
            'DB_CHARSET' => 'database.connections.mysql.charset',
            'V8_REDIRECT_MODE' => 'redirect.mode',
            'V8_DEBUG' => 'app.debug',
            'V8_LOG_LEVEL' => 'logging.level'
        ];
        
        if (isset($mappings[$key])) {
            $this->setNestedValue($this->config, $mappings[$key], $value);
        }
    }
    
    /**
     * Cargar variables de entorno del sistema
     */
    private function loadSystemEnvVars() {
        $systemVars = [
            'V8_ENVIRONMENT',
            'V8_REDIRECT_MODE',
            'V8_DEBUG',
            'V8_LOG_LEVEL',
            'DB_HOST',
            'DB_NAME',
            'DB_USER',
            'DB_PASS',
            'DB_PORT'
        ];
        
        foreach ($systemVars as $var) {
            $value = getenv($var);
            if ($value !== false) {
                $this->setEnvValue($var, $value);
            }
        }
    }
    
    /**
     * Detectar URL base
     */
    private function detectBaseUrl() {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
        
        // Remover nombre del script para obtener directorio base
        $basePath = dirname($scriptName);
        if ($basePath === '/' || $basePath === '\\') {
            $basePath = '';
        }
        
        return $protocol . '://' . $host . $basePath;
    }
    
    /**
     * Detectar si es una ruta de validación
     */
    public function isValidationPath($path) {
        $scriptName = basename($_SERVER['SCRIPT_NAME'] ?? '');
        
        foreach (self::VALIDATION_PATHS as $validationPath) {
            if ($scriptName === $validationPath || strpos($path, $validationPath) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Debe bypassar redirecciones
     */
    public function shouldBypassRedirects() {
        // Siempre bypassar rutas de validación
        $currentPath = $_SERVER['SCRIPT_NAME'] ?? '';
        if ($this->isValidationPath($currentPath)) {
            return true;
        }
        
        // Bypass según modo
        switch ($this->redirectMode) {
            case self::REDIRECT_DISABLED:
                return true;
            case self::REDIRECT_DEVELOPMENT:
                return $this->environment === self::ENV_DEVELOPMENT;
            case self::REDIRECT_INTELLIGENT:
                return $this->isDevelopmentRequest();
            default:
                return false;
        }
    }
    
    /**
     * Detectar si es una petición de desarrollo
     */
    private function isDevelopmentRequest() {
        $indicators = [
            'REMOTE_ADDR' => ['127.0.0.1', '::1'],
            'HTTP_HOST' => ['localhost', '127.0.0.1'],
            'SERVER_NAME' => ['localhost', '127.0.0.1']
        ];
        
        foreach ($indicators as $key => $values) {
            if (isset($_SERVER[$key]) && in_array($_SERVER[$key], $values)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Generar clave de encriptación
     */
    private function generateEncryptionKey() {
        return base64_encode(random_bytes(32));
    }
    
    /**
     * Generar secreto JWT
     */
    private function generateJwtSecret() {
        return bin2hex(random_bytes(64));
    }
    
    /**
     * Obtener nivel de log
     */
    private function getLogLevel() {
        $levels = [
            self::ENV_DEVELOPMENT => 'debug',
            self::ENV_TESTING => 'info',
            self::ENV_STAGING => 'warning',
            self::ENV_PRODUCTION => 'error'
        ];
        
        return $levels[$this->environment] ?? 'info';
    }
    
    /**
     * Validar configuración
     */
    private function validateConfiguration() {
        // Validar configuración crítica
        $required = [
            'app.name',
            'app.version',
            'app.environment',
            'database.connections.mysql.host',
            'database.connections.mysql.database'
        ];
        
        foreach ($required as $key) {
            if (!$this->getNestedValue($this->config, $key)) {
                throw new Exception("Configuración requerida faltante: $key");
            }
        }
    }
    
    /**
     * Establecer constantes para compatibilidad
     */
    private function setCompatibilityConstants() {
        // Constantes de base de datos para compatibilidad con código antiguo
        if (!defined('DB_HOST')) {
            define('DB_HOST', $this->config['database']['connections']['mysql']['host']);
        }
        if (!defined('DB_NAME')) {
            define('DB_NAME', $this->config['database']['connections']['mysql']['database']);
        }
        if (!defined('DB_USER')) {
            define('DB_USER', $this->config['database']['connections']['mysql']['username']);
        }
        if (!defined('DB_PASS')) {
            define('DB_PASS', $this->config['database']['connections']['mysql']['password']);
        }
        
        // Constantes de aplicación
        if (!defined('APP_VERSION')) {
            define('APP_VERSION', $this->config['app']['version']);
        }
        if (!defined('APP_ENVIRONMENT')) {
            define('APP_ENVIRONMENT', $this->config['app']['environment']);
        }
        if (!defined('APP_DEBUG')) {
            define('APP_DEBUG', $this->config['app']['debug']);
        }
    }
    
    /**
     * Merge de configuraciones
     */
    private function mergeConfig($base, $override) {
        foreach ($override as $key => $value) {
            if (is_array($value) && isset($base[$key]) && is_array($base[$key])) {
                $base[$key] = $this->mergeConfig($base[$key], $value);
            } else {
                $base[$key] = $value;
            }
        }
        
        return $base;
    }
    
    /**
     * Obtener valor anidado
     */
    private function getNestedValue($array, $key) {
        $keys = explode('.', $key);
        $value = $array;
        
        foreach ($keys as $k) {
            if (!isset($value[$k])) {
                return null;
            }
            $value = $value[$k];
        }
        
        return $value;
    }
    
    /**
     * Establecer valor anidado
     */
    private function setNestedValue(&$array, $key, $value) {
        $keys = explode('.', $key);
        $current = &$array;
        
        foreach ($keys as $i => $k) {
            if ($i === count($keys) - 1) {
                $current[$k] = $this->castValue($value);
            } else {
                if (!isset($current[$k]) || !is_array($current[$k])) {
                    $current[$k] = [];
                }
                $current = &$current[$k];
            }
        }
    }
    
    /**
     * Convertir valor al tipo correcto
     */
    private function castValue($value) {
        if ($value === 'true' || $value === '1') {
            return true;
        } elseif ($value === 'false' || $value === '0') {
            return false;
        } elseif (is_numeric($value)) {
            return strpos($value, '.') !== false ? (float)$value : (int)$value;
        }
        
        return $value;
    }
    
    /**
     * Getters públicos
     */
    public function getEnvironment() {
        return $this->environment;
    }
    
    public function getRedirectMode() {
        return $this->redirectMode;
    }
    
    public function getDatabaseConfig() {
        return $this->config['database']['connections']['mysql'];
    }
    
    public function getAllConfig() {
        return $this->config;
    }
    
    public function get($key, $default = null) {
        return $this->getNestedValue($this->config, $key) ?? $default;
    }
    
    public function isDebug() {
        return $this->config['app']['debug'];
    }
    
    public function isProduction() {
        return $this->environment === self::ENV_PRODUCTION;
    }
    
    public function isDevelopment() {
        return $this->environment === self::ENV_DEVELOPMENT;
    }
}

// Inicializar configuración global
try {
    $v8Config = V8Config::getInstance();
} catch (Exception $e) {
    error_log("Error inicializando V8Config: " . $e->getMessage());
    
    // Fallback básico
    if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
    if (!defined('DB_NAME')) define('DB_NAME', 'profixcrm');
    if (!defined('DB_USER')) define('DB_USER', 'root');
    if (!defined('DB_PASS')) define('DB_PASS', '');
}'');\n}