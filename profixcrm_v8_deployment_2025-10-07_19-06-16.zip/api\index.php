<?php
// Proxy sin .htaccess: delega todas las rutas API al controlador en /public
require_once __DIR__ . '/../public/index.php';